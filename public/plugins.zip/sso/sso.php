<?php

/**
 * Plugin Name: DS Care
 * Description: Dotsource Care plugin for SSO + site status — defensive so it won't bring the site down.
 * Version: 0.3.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class Laravel_SSO_Bridge
{
    const OPTION_KEY = 'laravel_sso_bridge_sites'; // array of [aud_base_url => secret]
    const ROUTE_NS = 'laravel-sso/v1';

    public function __construct()
    {
        // Register REST routes on rest_api_init
        add_action('rest_api_init', [$this, 'register_routes']);

        // Admin page and form handler
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_menu', [$this, 'main_menu_page']);
        add_action('admin_post_laravel_sso_save', [$this, 'save_settings']);
    }
    /**
     * Add main menu page (Welcome page)
     */
    public function main_menu_page()
    {
        add_menu_page(
            'DS Care Welcome',
            'DS Care',
            'manage_options',
            'ds-care-welcome',
            [$this, 'welcome_page'],
            'dashicons-shield-alt',
            2
        );
    }

    /**
     * Render the Welcome page with a beautiful design
     */
    public function welcome_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }
?>
        <style>
            .ds-care-welcome {
                background: linear-gradient(135deg, #f48120 0%, #ffcd6f 100%);
                color: #222;
                border-radius: 16px;
                padding: 40px 30px 30px 30px;
                margin: 40px auto;
                box-shadow: 0 8px 32px rgba(60, 60, 100, 0.12);
                font-family: 'Segoe UI', 'Arial', sans-serif;
            }

            .ds-care-welcome h1 {
                font-size: 2.5em;
                color: #1a365d;
                margin-bottom: 0.2em;
            }

            .ds-care-welcome .ds-logo {
                width: 80px;
                height: 80px;
                border-radius: 50%;
                background: #fff;
                background-size: 60px 60px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 20px;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
                position: relative;
                overflow: hidden;
            }

            .ds-care-welcome .ds-logo .dashicons {
                position: relative;
                z-index: 2;
                /* Optionally add a subtle shadow for contrast */
                text-shadow: 0 2px 8px rgba(0, 0, 0, 0.10);
            }

            .ds-care-welcome .ds-info {
                font-size: 1.2em;
                margin-bottom: 1.5em;
                color: #234e52;
            }

            .ds-care-welcome .ds-features {
                display: flex;
                flex-wrap: wrap;
                gap: 24px;
                margin-bottom: 2em;
            }

            .ds-care-welcome .ds-feature {
                flex: 1 1 220px;
                background: #fff;
                border-radius: 12px;
                padding: 24px 18px;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
                text-align: center;
                min-width: 200px;
            }

            .ds-care-welcome .ds-feature h3 {
                color: #2563eb;
                margin-bottom: 0.5em;
            }

            .ds-care-welcome .ds-footer {
                text-align: right;
                color: #234e52;
                font-size: 1em;
                margin-top: 2em;
            }

            @media (max-width: 700px) {
                .ds-care-welcome {
                    padding: 20px 5px;
                }

                .ds-care-welcome .ds-features {
                    flex-direction: column;
                    gap: 12px;
                }
            }
        </style>
        <div class="ds-care-welcome">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
                <div class="ds-logo">
                    <span class="dashicons dashicons-shield-alt" style="font-size:48px;color:#f28628;"></span>
                </div>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSVa7IBlV184mNUtcWKfeTFDHmcsYRTuVLlw2weRSOYVgrFnWZPoLZldukYeyWdxQcBog&usqp=CAU" alt="Brand Logo" style="height:64px;width:auto;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.10);background:#fff;object-fit:contain;max-width:180px;padding: 0px 15px;" />
            </div>
            <h1>Welcome to DS Care</h1>
            <div class="ds-info">
                <strong>DS Care</strong> is your all-in-one WordPress SSO, security, and site health plugin.<br>
                Secure, monitor, and manage your site with confidence.
            </div>
            <div class="ds-features">
                <div class="ds-feature"><span class="dashicons dashicons-unlock" style="font-size:32px;color:#10b981;"></span>
                    <h3>Single Sign-On (SSO)</h3>
                    <p>Seamless and secure login integration with your Laravel hub.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-shield" style="font-size:32px;color:#f59e42;"></span>
                    <h3>Site Status</h3>
                    <p>Monitor plugins, themes, users, and WordPress health at a glance.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-backup" style="font-size:32px;color:#6366f1;"></span>
                    <h3>Backups</h3>
                    <p>Easy, on-demand site and database backup for peace of mind.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-admin-users" style="font-size:32px;color:#ef4444;"></span>
                    <h3>User Management</h3>
                    <p>Quickly view and manage your site's users and roles.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-shield-alt" style="font-size:32px;color:#0ea5e9;"></span>
                    <h3>Malware Scans</h3>
                    <p>Scan your site for malware and threats automatically.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-clock" style="font-size:32px;color:#fbbf24;"></span>
                    <h3>Scan Frequency</h3>
                    <p>Set how often your site is scanned for threats.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-shield" style="font-size:32px;color:#6366f1;"></span>
                    <h3>Real-Time Firewall</h3>
                    <p>Block malicious traffic in real time with a smart firewall.</p>
                </div>

                <div class="ds-feature"><span class="dashicons dashicons-visibility" style="font-size:32px;color:#a21caf;"></span>
                    <h3>Bot Protection</h3>
                    <p>Stop bad bots from abusing your site and resources.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-search" style="font-size:32px;color:#0ea5e9;"></span>
                    <h3>Vulnerability Scanner</h3>
                    <p>Scan for plugin, theme, and core vulnerabilities.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-search" style="font-size:32px;color:#f59e42;"></span>
                    <h3>Website Audit</h3>
                    <p>Get a full audit of your website’s health and security.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-format-image" style="font-size:32px;color:#f59e42;"></span>
                    <h3>Visual Regression</h3>
                    <p>Detect visual changes after updates or deployments.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-controls-repeat" style="font-size:32px;color:#6366f1;"></span>
                    <h3>Safe Updates</h3>
                    <p>Test updates in a safe environment before applying.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-list-view" style="font-size:32px;color:#0ea5e9;"></span>
                    <h3>WP Activity Logs</h3>
                    <p>Track all important actions and changes on your site.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-dashboard" style="font-size:32px;color:#f59e42;"></span>
                    <h3>Uptime Monitoring</h3>
                    <p>Get notified if your website goes down.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-admin-site-alt" style="font-size:32px;color:#10b981;"></span>
                    <h3>Domain Monitoring</h3>
                    <p>Monitor your domain’s status and expiration.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-visibility" style="font-size:32px;color:#6366f1;"></span>
                    <h3>Visual Monitoring</h3>
                    <p>Monitor your site’s appearance and detect unwanted changes.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-warning" style="font-size:32px;color:#ef4444;"></span>
                    <h3>PHP Error Monitoring</h3>
                    <p>Catch and log PHP errors in real time.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-lock" style="font-size:32px;color:#2563eb;"></span>
                    <h3>SSL Monitoring</h3>
                    <p>Ensure your SSL certificate is always valid and secure.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-email" style="font-size:32px;color:#0ea5e9;"></span>
                    <h3>Email Support</h3>
                    <p>Get fast, expert help when you need it.</p>
                </div>
            </div>
            <div class="ds-footer">
                <em>Version 0.3.0 &mdash; Crafted with <span style="color:#e53e3e;">&hearts;</span> by Dotsource</em>
            </div>
        </div>
    <?php
    }

    public function register_routes()
    {
        register_rest_route(self::ROUTE_NS, '/login', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'handle_login'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route(self::ROUTE_NS, '/add-secret-token', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'handle_token'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route(self::ROUTE_NS, '/update-secret-token', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'handle_update_token'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route(self::ROUTE_NS, '/status', [
            'methods' => ['GET'],
            'callback' => [$this, 'handle_status'],
            'permission_callback' =>  '__return_true',
        ]);
        register_rest_route(self::ROUTE_NS, '/plugins_list', [
            'methods' => ['GET'],
            'callback' => [$this, 'handle_plugins'],
            'permission_callback' =>  [$this, 'check_auth'],
        ]);
        register_rest_route(self::ROUTE_NS, '/manage_users', [
            'methods' => ['GET'],
            'callback' => [$this, 'manage_users'],
            'permission_callback' =>  [$this, 'check_auth'],
        ]);
        register_rest_route(self::ROUTE_NS, '/handle_backup', [
            'methods' => ['GET'],
            'callback' => [$this, 'handle_backup'],
            'permission_callback' =>  '__return_true',
        ]);
        register_rest_route(self::ROUTE_NS, '/delete-backup', [
            'methods' => ['GET'],
            'callback' => [$this, 'handle_delete_backup'],
            'permission_callback' => '__return_true', // you can add check_auth here if needed
        ]);
        register_rest_route(self::ROUTE_NS, '/upgrade', [
            'methods' =>  ['GET'],
            'callback' => [$this, 'update_item'],
            'permission_callback' =>  [$this, 'check_auth'],
        ]);
    }

    /**
     * Permission callback: verifies shared secret signature.
     * Expects 'iss' and 'sig' params (GET or POST).
     */
    public function check_auth($req)
    {
        try {
            $iss = $req->get_param('iss');
            $sig = $req->get_param('sig');

            if (empty($iss) || empty($sig)) {
                return false;
            }

            $map = get_option(self::OPTION_KEY, []);
            $iss = rtrim($iss, '/');

            if (!isset($map[$iss])) {
                return false;
            }

            $secret = $map[$iss];
            // compute signature: HMAC sha256 of iss, base64
            $calc = base64_encode(hash_hmac('sha256', $iss, $secret, true));

            // timing-safe comparison
            return hash_equals($calc, $sig);
        } catch (\Throwable $e) {
            error_log('laravel_sso_bridge::check_auth error: ' . $e->getMessage());
            return false;
        }
    }

    public function admin_menu()
    {
        add_options_page('DS Care', 'DS Care', 'manage_options', 'laravel-sso-bridge', [$this, 'settings_page']);
    }

    public function settings_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $map = get_option(self::OPTION_KEY, []);
    ?>
        <div class="wrap">
            <h1>DS Care</h1>
            <p>Add your Laravel hub base URL and shared secret (one row per hub). For most setups, you will have exactly one hub.</p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('laravel_sso_save'); ?>
                <input type="hidden" name="action" value="laravel_sso_save" />
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>Laravel Hub Base URL (iss)</th>
                            <th>Shared Secret</th>
                        </tr>
                    </thead>
                    <tbody id="laravel-sso-rows">
                        <?php if (!empty($map) && is_array($map)): ?>
                            <?php foreach ($map as $iss => $secret): ?>
                                <tr>
                                    <td><input style="width:100%" name="iss[]" value="<?php echo esc_attr($iss); ?>"></td>
                                    <td><input style="width:100%" name="secret[]" value="<?php echo esc_attr($secret); ?>"></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        <tr>
                            <td><input style="width:100%" name="iss[]" placeholder="https://laravel-hub.example.com"></td>
                            <td><input style="width:100%" name="secret[]" placeholder="paste secret from Laravel site record"></td>
                        </tr>
                    </tbody>
                </table>
                <p><button class="button button-primary">Save</button></p>
            </form>
        </div>
<?php
    }

    /**
     * Save settings (admin_post)
     */
    public function save_settings()
    {
        if (!current_user_can('manage_options')) {
            wp_die('forbidden', '', ['response' => 403]);
        }
        check_admin_referer('laravel_sso_save');

        $iss = isset($_POST['iss']) ? array_map('sanitize_text_field', (array)$_POST['iss']) : [];
        $sec = isset($_POST['secret']) ? array_map('sanitize_text_field', (array)$_POST['secret']) : [];

        $map = [];
        foreach ($iss as $i => $val) {
            $val = rtrim($val, '/');
            if ($val && !empty($sec[$i])) {
                $map[$val] = $sec[$i];
            }
        }

        update_option(self::OPTION_KEY, $map);
        wp_redirect(admin_url('options-general.php?page=laravel-sso-bridge&updated=1'));
        exit; // safe here — final in admin_post flow
    }

    /**
     * Save a single credential pair — does NOT exit.
     * Returns true on success, WP_Error on failure.
     */
    public function save_creds($url, $token)
    {
        try {
            if (empty($url) || empty($token)) {
                return new WP_Error('invalid_input', 'url and token required', ['status' => 400]);
            }

            $iss = rtrim(sanitize_text_field($url), '/');
            $sec = sanitize_text_field($token);

            if (empty($iss) || empty($sec)) {
                return new WP_Error('invalid_input', 'invalid url or token after sanitization', ['status' => 400]);
            }

            // Merge with existing entries instead of overwriting everything
            $map = get_option(self::OPTION_KEY, []);
            if (!is_array($map)) {
                $map = [];
            }

            $map[$iss] = $sec;

            update_option(self::OPTION_KEY, $map);
            return true;
        } catch (\Throwable $e) {
            error_log('laravel_sso_bridge::save_creds error: ' . $e->getMessage());
            return new WP_Error('save_failed', 'failed to save credentials', ['status' => 500]);
        }
    }

    public function update_creds($url, $token)
    {
        try {
            if (empty($url) || empty($token)) {
                return new WP_Error('invalid_input', 'url and token required', ['status' => 400]);
            }

            $iss = rtrim(sanitize_text_field($url), '/');
            $sec = sanitize_text_field($token);

            if (empty($iss) || empty($sec)) {
                return new WP_Error('invalid_input', 'invalid url or token after sanitization', ['status' => 400]);
            }

            $map = get_option(self::OPTION_KEY, []);
            if (!is_array($map)) {
                $map = [];
            }

            if (!isset($map[$iss])) {
                return new WP_Error('not_found', 'issuer not found, cannot update', ['status' => 404]);
            }

            $map[$iss] = $sec;
            update_option(self::OPTION_KEY, $map);

            return true;
        } catch (\Throwable $e) {
            error_log('laravel_sso_bridge::update_creds error: ' . $e->getMessage());
            return new WP_Error('update_failed', 'failed to update credentials', ['status' => 500]);
        }
    }

    /**
     * Add secret/token via REST endpoint. GET/POST allowed.
     * Params: url, token
     */
    public function handle_token(\WP_REST_Request $req)
    {
        try {
            $url = $req->get_param('url');
            $token = $req->get_param('token');

            if (empty($url) || empty($token)) {
                return new \WP_REST_Response(['error' => 'missing_params'], 400);
            }

            $res = $this->save_creds($url, $token);
            if (is_wp_error($res)) {
                $code = $res->get_error_code();
                $msg = $res->get_error_message();
                $status = $res->get_error_data()['status'] ?? 500;
                return new \WP_REST_Response(['error' => $code, 'message' => $msg], $status);
            }

            return new \WP_REST_Response(['status' => 'saved'], 200);
        } catch (\Throwable $e) {
            error_log('laravel_sso_bridge::handle_token error: ' . $e->getMessage());
            return new \WP_REST_Response(['error' => 'internal_error', 'message' => $e->getMessage()], 500);
        }
    }

    public function handle_update_token(\WP_REST_Request $req)
    {
        try {
            $url = $req->get_param('url');
            $token = $req->get_param('token');

            if (empty($url) || empty($token)) {
                return new \WP_REST_Response(['error' => 'missing_params'], 400);
            }

            $res = $this->update_creds($url, $token);
            if (is_wp_error($res)) {
                $code = $res->get_error_code();
                $msg = $res->get_error_message();
                $status = $res->get_error_data()['status'] ?? 500;
                return new \WP_REST_Response(['error' => $code, 'message' => $msg], $status);
            }

            return new \WP_REST_Response(['status' => 'saved'], 200);
        } catch (\Throwable $e) {
            error_log('laravel_sso_bridge::handle_token error: ' . $e->getMessage());
            return new \WP_REST_Response(['error' => 'internal_error', 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Handle login request
     * Expects payload (JSON string), sig, optional redirect
     */
    public function handle_login(\WP_REST_Request $req)
    {
        try {
            $payload = $req->get_param('payload');
            $sig = $req->get_param('sig');
            $redirect = $req->get_param('redirect');

            if (empty($payload) || empty($sig)) {
                return $this->error('missing_params', 400);
            }

            $data = json_decode($payload, true);
            if (!$data || !is_array($data)) {
                return $this->error('bad_payload', 400);
            }

            $iss = isset($data['iss']) ? rtrim($data['iss'], '/') : '';
            $aud = isset($data['aud']) ? rtrim($data['aud'], '/') : '';
            $email = isset($data['email']) ? sanitize_email($data['email']) : '';
            $exp = isset($data['exp']) ? intval($data['exp']) : 0;
            $nonce = isset($data['nonce']) ? sanitize_text_field($data['nonce']) : '';

            if (!$iss || !$aud || !$email || !$exp || !$nonce) {
                return $this->error('missing_claims', 400);
            }

            if ($aud !== rtrim(get_site_url(), '/')) {
                return $this->error('aud_mismatch', 400);
            }

            $map = get_option(self::OPTION_KEY, []);
            if (!isset($map[$iss])) {
                return $this->error('unknown_issuer', 400);
            }

            $secret = $map[$iss];
            $calc = base64_encode(hash_hmac('sha256', $payload, $secret, true));
            if (!hash_equals($calc, $sig)) {
                return $this->error('bad_signature', 400);
            }

            if (time() > $exp) {
                return $this->error('expired', 400);
            }

            // prevent immediate replay by transient (short TTL)
            $tkey = 'laravel_sso_used_' . md5($nonce);
            if (get_transient($tkey)) {
                return $this->error('replayed', 400);
            }
            set_transient($tkey, 1, 5 * MINUTE_IN_SECONDS);

            $user = get_user_by('email', $email);
            if (!$user) {
                return $this->error('not_admin', 403);
            }

            if (!in_array('administrator', (array) $user->roles, true)) {
                return $this->error('not_admin', 403);
            }

            // Login the admin user
            wp_set_current_user($user->ID);
            // set auth cookie — consider false if you prefer non-persistent
            wp_set_auth_cookie($user->ID, true);

            // Sanitize redirect and ensure it stays within site
            $dest = $redirect ? esc_url_raw($redirect) : admin_url();
            $site_url = rtrim(get_site_url(), '/');
            if (strpos($dest, $site_url) !== 0) {
                $dest = admin_url();
            }

            // Use wp_safe_redirect when possible
            wp_safe_redirect($dest);
            exit; // final redirect; allowed here
        } catch (\Throwable $e) {
            error_log('laravel_sso_bridge::handle_login error: ' . $e->getMessage());
            return $this->error('internal_error', 500);
        }
    }

    /**
     * Status endpoint — defensive: checks function existence and catches exceptions.
     * Requires check_auth permission callback to pass.
     */
    public function handle_status(\WP_REST_Request $req)
    {
        try {
            // Load plugin/theme/update functions safely
            $wp_admin_path = ABSPATH . 'wp-admin/includes';
            try {
                if (!function_exists('get_plugins') && file_exists($wp_admin_path . '/plugin.php')) {
                    require_once $wp_admin_path . '/plugin.php';
                }
                if (!function_exists('get_plugin_updates') && file_exists($wp_admin_path . '/update.php')) {
                    require_once $wp_admin_path . '/update.php';
                }
                if (!function_exists('wp_get_themes') && file_exists($wp_admin_path . '/theme.php')) {
                    require_once $wp_admin_path . '/theme.php';
                }
            } catch (\Throwable $e) {
                error_log('handle_status include failed: ' . $e->getMessage());
            }

            global $wp_version;

            // 🔹 WP update check
            $wp_update = null;
            try {
                if (function_exists('wp_version_check')) {
                    wp_version_check();
                }
                $updates = function_exists('get_core_updates') ? get_core_updates() : [];
                if (is_array($updates) && isset($updates[0]->current)) {
                    $wp_update = $updates[0]->current;
                }
            } catch (\Throwable $inner) {
                error_log('handle_status wp update failed: ' . $inner->getMessage());
            }

            // 🔹 Plugins
            $plugins        = function_exists('get_plugins') ? (array) get_plugins() : [];
            $active_plugins = (array) get_option('active_plugins', []);
            $plugin_updates = function_exists('get_plugin_updates') ? (array) get_plugin_updates() : [];

            $plugin_items = [];
            foreach ($plugins as $path => $details) {
                try {
                    $is_active    = in_array($path, $active_plugins, true);
                    $update_avail = $plugin_updates[$path] ?? null;

                    // Icon detection
                    $icon_url = 'https://s.w.org/plugins/geopattern-icon.png';
                    if ($update_avail && isset($update_avail->update->icons) && is_array($update_avail->update->icons)) {
                        $icons = $update_avail->update->icons;
                        $icon_url = $icons['svg'] ?? $icons['2x'] ?? $icons['1x'] ?? $icons['default'] ?? $icon_url;
                    }

                    $plugin_items[] = [
                        'name'       => $details['Name'] ?? 'unknown',
                        'version'    => $details['Version'] ?? 'unknown',
                        'author'     => $details['Author'] ?? '',
                        'plugin_uri' => $details['PluginURI'] ?? '',
                        'file_path'  => $path,
                        'is_active'  => $is_active,
                        'icon_url'   => $icon_url,
                        'update'     => $update_avail ? [
                            'new_version' => $update_avail->update->new_version ?? null,
                            'package'     => $update_avail->package ?? null,
                            'slug'        => $update_avail->update->slug ?? null,
                        ] : null,
                    ];
                } catch (\Throwable $e) {
                    error_log('handle_status plugin parse failed: ' . $e->getMessage());
                }
            }

            // 🔹 Themes
            $themes        = function_exists('wp_get_themes') ? (array) wp_get_themes() : [];
            $current_theme = function_exists('wp_get_theme') ? wp_get_theme() : null;

            $theme_items = [];
            foreach ($themes as $slug => $theme) {
                try {
                    $theme_items[] = [
                        'name'       => $theme->get('Name') ?: 'unknown',
                        'version'    => $theme->get('Version') ?: 'unknown',
                        'author'     => $theme->get('Author') ?: '',
                        'theme_uri'  => $theme->get('ThemeURI') ?: '',
                        'slug'       => $slug,
                        'is_active'  => ($current_theme && $theme->get_stylesheet() === $current_theme->get_stylesheet()),
                        'screenshot' => $theme->get_screenshot() ?: 'https://s.w.org/style/images/about/WordPress-logotype-wmark.png',
                    ];
                } catch (\Throwable $e) {
                    error_log('handle_status theme parse failed: ' . $e->getMessage());
                }
            }

            // 🔹 Users
            $user_result = [];
            try {
                $users = function_exists('get_users') ? get_users() : [];
                foreach ($users as $user) {
                    $user_result[] = [
                        'id'       => $user->ID,
                        'username' => $user->user_login,
                        'email'    => $user->user_email,
                        'roles'    => $user->roles,
                        'name'     => $user->display_name,
                    ];
                }
            } catch (\Throwable $e) {
                error_log('handle_status users failed: ' . $e->getMessage());
            }

            $site_health_result = [];
            try {
                // Include necessary WordPress admin files
                if (!class_exists('WP_Site_Health')) {
                    require_once ABSPATH . 'wp-admin/includes/class-wp-site-health.php';
                }
                if (!function_exists('wp_check_php_version')) {
                    require_once ABSPATH . 'wp-admin/includes/misc.php';
                }

                if (class_exists('WP_Site_Health')) {
                    $site_health = new \WP_Site_Health();

                    // Get all available tests
                    $tests = $site_health->get_tests();

                    $direct_results = [];
                    $async_results = [];

                    // Execute direct tests dynamically with proper argument handling
                    if (!empty($tests['direct'])) {
                        foreach ($tests['direct'] as $test_name => $test_args) {
                            try {
                                $result = null;

                                if (isset($test_args['test'])) {
                                    $callback = $test_args['test'];

                                    // Handle method calls to WP_Site_Health instance
                                    if (is_string($callback) && method_exists($site_health, $callback)) {
                                        // Use reflection to check if method needs arguments
                                        $reflection = new \ReflectionMethod($site_health, $callback);
                                        $params = $reflection->getParameters();

                                        if (count($params) === 0) {
                                            $result = $site_health->$callback();
                                        } else {
                                            // Skip tests that require specific arguments we don't have
                                            continue;
                                        }
                                    }
                                    // Handle array callbacks [class, method]
                                    elseif (is_array($callback) && count($callback) === 2) {
                                        list($class, $method) = $callback;

                                        if ($class === $site_health || $class === 'WP_Site_Health') {
                                            $reflection = new \ReflectionMethod($site_health, $method);
                                            $params = $reflection->getParameters();

                                            if (count($params) === 0) {
                                                $result = $site_health->$method();
                                            }
                                        } elseif (is_callable($callback)) {
                                            // Check if callable needs arguments
                                            try {
                                                $reflection = new \ReflectionFunction($callback);
                                                if ($reflection->getNumberOfRequiredParameters() === 0) {
                                                    $result = call_user_func($callback);
                                                }
                                            } catch (\Exception $e) {
                                                // Skip if we can't reflect
                                                continue;
                                            }
                                        }
                                    }
                                    // Handle direct function calls
                                    elseif (is_callable($callback)) {
                                        try {
                                            if (is_string($callback) && function_exists($callback)) {
                                                $reflection = new \ReflectionFunction($callback);
                                                if ($reflection->getNumberOfRequiredParameters() === 0) {
                                                    $result = call_user_func($callback);
                                                }
                                            } else {
                                                $result = call_user_func($callback);
                                            }
                                        } catch (\Exception $e) {
                                            continue;
                                        }
                                    }

                                    if (isset($result) && is_array($result)) {
                                        $direct_results[$test_name] = array_merge([
                                            'test' => $test_name,
                                            'label' => $test_args['label'] ?? ucwords(str_replace('_', ' ', $test_name))
                                        ], $result);
                                    }
                                }
                            } catch (\Throwable $test_error) {
                                // Log but don't include failed tests in results
                                error_log("Site health direct test '{$test_name}' failed: " . $test_error->getMessage());
                            }
                        }
                    }

                    // Handle async tests - force run some key ones that can run synchronously
                    if (!empty($tests['async'])) {
                        foreach ($tests['async'] as $test_name => $test_args) {
                            try {
                                $result = null;

                                // First check cached results
                                $transient_key = 'health-check-site-status-result';
                                $cached_results = get_transient($transient_key);

                                if (is_array($cached_results) && isset($cached_results[$test_name])) {
                                    $result = $cached_results[$test_name];
                                } else {
                                    // Try to run specific async tests that we can execute immediately
                                    switch ($test_name) {
                                        case 'dotorg_communication':
                                            if (method_exists($site_health, 'get_test_dotorg_communication')) {
                                                $result = $site_health->get_test_dotorg_communication();
                                            }
                                            break;

                                        case 'https_status':
                                            if (method_exists($site_health, 'get_test_https_status')) {
                                                $result = $site_health->get_test_https_status();
                                            }
                                            break;

                                        case 'loopback_requests':
                                            if (method_exists($site_health, 'get_test_loopback_requests')) {
                                                $result = $site_health->get_test_loopback_requests();
                                            }
                                            break;

                                        case 'background_updates':
                                            if (method_exists($site_health, 'get_test_background_updates')) {
                                                $result = $site_health->get_test_background_updates();
                                            }
                                            break;

                                        case 'authorization_header':
                                            if (method_exists($site_health, 'get_test_authorization_header')) {
                                                $result = $site_health->get_test_authorization_header();
                                            }
                                            break;

                                        case 'page_cache':
                                            if (method_exists($site_health, 'get_test_page_cache')) {
                                                $result = $site_health->get_test_page_cache();
                                            }
                                            break;
                                    }
                                }

                                if (is_array($result)) {
                                    $async_results[$test_name] = array_merge([
                                        'test' => $test_name,
                                        'label' => $test_args['label'] ?? ucwords(str_replace('_', ' ', $test_name)),
                                        'async' => true
                                    ], $result);
                                }
                            } catch (\Throwable $test_error) {
                                error_log("Site health async test '{$test_name}' failed: " . $test_error->getMessage());
                            }
                        }
                    }

                    // Calculate dynamic summary
                    $summary = [
                        'critical' => 0,
                        'recommended' => 0,
                        'good' => 0,
                    ];

                    $all_results = array_merge($direct_results, $async_results);
                    foreach ($all_results as $test_result) {
                        if (!empty($test_result['status']) && isset($summary[$test_result['status']])) {
                            $summary[$test_result['status']]++;
                        }
                    }

                    // Get site health score dynamically
                    $site_health_score = null;
                    try {
                        $total_tests = count($all_results);
                        if ($total_tests > 0) {
                            $good_tests = $summary['good'];
                            $recommended_tests = $summary['recommended'];
                            $critical_tests = $summary['critical'];

                            // WordPress scoring: good = 100%, recommended = 50%, critical = 0%
                            $score = (($good_tests * 100) + ($recommended_tests * 50)) / $total_tests;
                            $site_health_score = round($score);
                        }
                    } catch (\Throwable $e) {
                        error_log('Site health score calculation failed: ' . $e->getMessage());
                    }

                    // Get system information dynamically
                    $info = [];
                    try {
                        // Get basic system info without debug_data if it's problematic
                        global $wpdb;

                        $info = [
                            'wp_version' => get_bloginfo('version'),
                            'php_version' => PHP_VERSION,
                            'php_sapi' => php_sapi_name(),
                            'memory_limit' => ini_get('memory_limit'),
                            'max_execution_time' => ini_get('max_execution_time'),
                            'upload_max_filesize' => ini_get('upload_max_filesize'),
                            'post_max_size' => ini_get('post_max_size'),
                            'mysql_version' => $wpdb->db_version(),
                            'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
                            'https_enabled' => is_ssl(),
                            'multisite' => is_multisite(),
                            'wp_debug' => defined('WP_DEBUG') && WP_DEBUG,
                            'wp_cache' => defined('WP_CACHE') && WP_CACHE,
                        ];
                    } catch (\Throwable $e) {
                        error_log('Site health system info failed: ' . $e->getMessage());
                    }

                    $site_health_result = [
                        'status_summary' => $summary,
                        'direct_tests' => $direct_results,
                        'async_tests' => $async_results,
                        'total_tests' => count($all_results),
                        'score' => $site_health_score,
                        'system_info' => $info,
                        'last_updated' => current_time('mysql'),
                        'has_critical_issues' => $summary['critical'] > 0,
                        'has_recommended_improvements' => $summary['recommended'] > 0,
                    ];
                }
            } catch (\Throwable $e) {
                error_log('handle_status site health failed: ' . $e->getMessage());
                $site_health_result = [
                    'error' => $e->getMessage(),
                    'fallback_info' => [
                        'php_version' => PHP_VERSION,
                        'wp_version' => get_bloginfo('version'),
                        'memory_limit' => ini_get('memory_limit'),
                        'https_enabled' => is_ssl(),
                        'last_updated' => current_time('mysql')
                    ]
                ];
            }

            // 🔹 Site Info
            $site_name        = function_exists('get_bloginfo') ? get_bloginfo('name') : 'unknown';
            $site_description = function_exists('get_bloginfo') ? get_bloginfo('description') : '';
            $site_url         = function_exists('get_site_url') ? get_site_url() : '';
            $meta_title       = get_option('blogname', $site_name);
            $meta_description = get_option('blogdescription', $site_description);

            // Site Logo
            $logo_url = null;
            try {
                if (function_exists('get_theme_mod') && function_exists('wp_get_attachment_image_url')) {
                    $logo_id = get_theme_mod('custom_logo');
                    if ($logo_id) {
                        $logo_url = wp_get_attachment_image_url($logo_id, 'full');
                    }
                }
            } catch (\Throwable $e) {
                error_log('handle_status logo fetch failed: ' . $e->getMessage());
            }

            // User counts
            $counts      = function_exists('count_users') ? count_users() : ['total_users' => 0, 'avail_roles' => []];
            $admin_count = $counts['avail_roles']['administrator'] ?? 0;

            // 🔹 Final Payload
            $payload = [
                "site_name"                  => $site_name,
                "site_logo_url"              => $logo_url,
                "wordpress_version"          => $wp_version ?? 'unknown',
                "php_version"                => phpversion(),
                "wordpress_update_available" => $wp_update,
                "icon_url"                   => "https://s.w.org/style/images/about/WordPress-logotype-simplified.png",
                'site_health'               => $site_health_result,
                "site" => [
                    "name"            => $site_name,
                    "description"     => $site_description,
                    "url"             => $site_url,
                    "meta_title"      => $meta_title,
                    "meta_description" => $meta_description,
                ],
                "plugins" => [
                    "total"   => count($plugins),
                    "active"  => count($active_plugins),
                    "updates" => count($plugin_updates),
                    "items"   => $plugin_items,
                ],
                "themes" => [
                    "total"   => count($themes),
                    "current" => $current_theme ? $current_theme->get('Name') : 'unknown',
                    "items"   => $theme_items,
                ],
                "users" => [
                    "total"  => $counts['total_users'] ?? 0,
                    "admins" => $admin_count,
                    "items"  => $user_result,
                ],
                // Reserved keys
                "backup"       => "unknown",
                "security"     => "unknown",
                "staging"      => "unknown",
                "activity_log" => "unknown",
                "performance"  => "unknown",
            ];

            return new \WP_REST_Response($payload, 200);
        } catch (\Throwable $e) {
            error_log('handle_status fatal: ' . $e->getMessage());
            return new \WP_REST_Response([
                'error'   => 'status_failed',
                'message' => $e->getMessage(),
            ], 500);
        }
    }
    public function update_item(\WP_REST_Request $request)
    {

        $type   = $request->get_param('type');   // plugin, theme, core
        $slug   = $request->get_param('slug');   // e.g. "akismet/akismet.php" or "twentytwentyfive"
        $action = $request->get_param('action'); // update, activate, deactivate

        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/theme.php';
        require_once ABSPATH . 'wp-admin/includes/update.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/misc.php';

        wp_cache_flush();

        $result = null;

        // ✅ PLUGIN actions
        if ($type === 'plugin' && $slug) {
            if ($action === 'update') {
                wp_update_plugins();
                $upgrader = new \Plugin_Upgrader(new \Automatic_Upgrader_Skin());
                $result   = $upgrader->upgrade($slug);
            } elseif ($action === 'activate') {
                $result = activate_plugin($slug);
                if (is_wp_error($result)) {
                    return new \WP_REST_Response(['error' => $result->get_error_message()], 500);
                }
            } elseif ($action === 'deactivate') {
                deactivate_plugins($slug);
                $result = true;
            } elseif ($action === 'delete') {
                // Slug must be plugin file path like "akismet/akismet.php"
                $result = delete_plugins([$slug]);
                if (is_wp_error($result)) {
                    return new \WP_REST_Response(['error' => $result->get_error_message()], 500);
                }
            }
        }

        // ✅ THEME actions
        elseif ($type === 'theme' && $slug) {
            if ($action === 'update' && $slug) {
                wp_update_themes();
                $upgrader = new \Theme_Upgrader(new \Automatic_Upgrader_Skin());
                $result   = $upgrader->upgrade($slug);
            } elseif ($action === 'activate' && $slug) {
                switch_theme($slug);
                $result = true;
            } elseif ($action === 'deactivate' && $slug) {
                // WordPress doesn’t allow "deactivate theme" directly, 
                // you can only switch to another one.
                $result = 'Theme cannot be deactivated without switching to another theme';
            } elseif ($action === 'delete' && $slug) {
                // Slug must be theme folder name like "twentytwentyfive"
                if (wp_get_theme()->get_stylesheet() === $slug) {
                    return new \WP_REST_Response(['error' => 'Cannot delete the currently active theme'], 400);
                }
                $result = delete_theme($slug);
                if (is_wp_error($result)) {
                    return new \WP_REST_Response(['error' => $result->get_error_message()], 500);
                }
            }
        }

        // ✅ CORE update only
        elseif ($type === 'core' && $action === 'update') {
            wp_version_check();
            $update = find_core_update(false, false);

            if ($update) {
                $upgrader = new \Core_Upgrader(new \Automatic_Upgrader_Skin());
                $result   = $upgrader->upgrade($update);
            } else {
                $result = 'No core update available';
            }
        } else {
            return new \WP_REST_Response([
                'error' => 'Invalid request. Provide type=plugin|theme|core, slug if needed, and action=update|activate|deactivate'
            ], 400);
        }

        if ($result === false) {
            return new \WP_REST_Response(['message' => ucfirst($type) . ' action failed'], 500);
        }

        return new \WP_REST_Response([
            'message' => ucfirst($type) . ' ' . $action . ' process completed',
            'result'  => $result,
        ], 200);
    }




    public function handle_plugins(\WP_REST_Request $req)
    {
        try {
            // Load plugin + update functions safely
            if (!function_exists('get_plugins') || !function_exists('get_plugin_updates')) {
                $wp_admin_path = ABSPATH . 'wp-admin/includes';
                if (file_exists($wp_admin_path . '/plugin.php')) {
                    require_once $wp_admin_path . '/plugin.php';
                }
                if (file_exists($wp_admin_path . '/update.php')) {
                    require_once $wp_admin_path . '/update.php';
                }
            }

            // Get plugin data
            $plugins        = function_exists('get_plugins') ? get_plugins() : [];
            $active_plugins = get_option('active_plugins', []);
            $plugin_updates = function_exists('get_plugin_updates') ? get_plugin_updates() : [];

            $result = [];
            if (is_array($plugins)) {
                foreach ($plugins as $path => $details) {
                    $is_active     = in_array($path, $active_plugins, true);
                    $update_avail = isset($plugin_updates[$path]) ? $plugin_updates[$path] : null;

                    // Try to extract icon (if update API provides it)
                    $icon_url = null;
                    if ($update_avail && isset($update_avail->update->icons) && is_array($update_avail->update->icons)) {
                        if (!empty($update_avail->update->icons['svg'])) {
                            $icon_url = $update_avail->update->icons['svg'];
                        } elseif (!empty($update_avail->update->icons['2x'])) {
                            $icon_url = $update_avail->update->icons['2x'];
                        } elseif (!empty($update_avail->update->icons['1x'])) {
                            $icon_url = $update_avail->update->icons['1x'];
                        } elseif (!empty($update_avail->update->icons['default'])) {
                            $icon_url = $update_avail->update->icons['default'];
                        }
                    }

                    // Fallback icon if none available
                    if (!$icon_url) {
                        $icon_url = 'https://s.w.org/plugins/geopattern-icon.png';
                    }


                    $result[] = [
                        'name'        => $details['Name'] ?? 'unknown',
                        'version'     => $details['Version'] ?? 'unknown',
                        'author'      => $details['Author'] ?? '',
                        'plugin_uri'  => $details['PluginURI'] ?? '',
                        'file_path'   => $path,
                        'is_active'   => $is_active,
                        'icon_url'   => $icon_url,
                        'update'      => $update_avail ? [
                            'new_version' => $update_avail->update->new_version ?? null,
                            'package'     => $update_avail->package ?? null,
                            'slug'        => $update_avail->update->slug ?? null,
                        ] : null,
                    ];
                }
            }

            $payload = [
                "total"  => is_array($plugins) ? count($plugins) : 0,
                "active" => is_array($active_plugins) ? count($active_plugins) : 0,
                "updates" => is_array($plugin_updates) ? count($plugin_updates) : 0,
                "items"  => $result,
            ];

            return new \WP_REST_Response($payload, 200);
        } catch (\Throwable $e) {
            error_log('laravel_sso_bridge::handle_plugins error: ' . $e->getMessage());
            return new \WP_REST_Response(['error' => 'plugins_failed', 'message' => $e->getMessage()], 500);
        }
    }

    public function manage_users(\WP_REST_Request $request)
    {
        try {
            $action = $request->get_param('action'); // create, update, delete, get, list
            $user_id = $request->get_param('id');

            // CREATE user
            if ($action === 'create') {
                $userdata = [
                    'user_login' => sanitize_user($request->get_param('username')),
                    'user_email' => sanitize_email($request->get_param('email')),
                    'user_pass'  => $request->get_param('password'),
                    'display_name' => sanitize_text_field($request->get_param('name')),
                    'role' => $request->get_param('role') ?? 'subscriber',
                ];
                $result = wp_insert_user($userdata);
                if (is_wp_error($result)) {
                    return new \WP_REST_Response(['error' => $result->get_error_message()], 500);
                }
            }

            // UPDATE user
            elseif ($action === 'update' && $user_id) {
                $userdata = ['ID' => (int)$user_id];
                if ($request->get_param('email')) $userdata['user_email'] = sanitize_email($request->get_param('email'));
                if ($request->get_param('name')) $userdata['display_name'] = sanitize_text_field($request->get_param('name'));
                if ($request->get_param('password')) $userdata['user_pass'] = $request->get_param('password');
                if ($request->get_param('role')) $userdata['role'] = $request->get_param('role');

                $result = wp_update_user($userdata);
                if (is_wp_error($result)) {
                    return new \WP_REST_Response(['error' => $result->get_error_message()], 500);
                }
            }

            // DELETE user
            elseif ($action === 'delete' && $user_id) {
                require_once ABSPATH . 'wp-admin/includes/user.php';
                $reassign = $request->get_param('reassign') ?? null; // reassign posts to another user ID
                $result = wp_delete_user((int)$user_id, $reassign);
                if (!$result) {
                    return new \WP_REST_Response(['error' => 'User deletion failed'], 500);
                }
            }

            // GET single user
            elseif ($action === 'get' && $user_id) {
                $user = get_userdata((int)$user_id);
                if (!$user) {
                    return new \WP_REST_Response(['error' => 'User not found'], 404);
                }
                $result = [
                    'id' => $user->ID,
                    'username' => $user->user_login,
                    'email' => $user->user_email,
                    'name' => $user->display_name,
                    'roles' => $user->roles,
                ];
            }

            // LIST all users
            elseif ($action === 'list') {
                $args = [
                    'role__in' => $request->get_param('roles') ? explode(',', $request->get_param('roles')) : [],
                    'number'   => $request->get_param('per_page') ?? 20,
                    'paged'    => $request->get_param('page') ?? 1,
                ];
                $users = get_users($args);
                $result = array_map(function ($user) {
                    return [
                        'id' => $user->ID,
                        'username' => $user->user_login,
                        'email' => $user->user_email,
                        'name' => $user->display_name,
                        'roles' => $user->roles,
                    ];
                }, $users);
            } else {
                return new \WP_REST_Response(['error' => 'Invalid action'], 400);
            }

            return new \WP_REST_Response([
                'message' => 'User action completed',
                'result' => $result,
            ], 200);
        } catch (\Throwable $e) {
            return new \WP_REST_Response([
                'error' => 'user_action_failed',
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function handle_backup(\WP_REST_Request $req)
    {
        try {
            $upload_dir = wp_upload_dir();
            $backup_dir = $upload_dir['basedir'] . '/laravel_backups';

            // Ensure backup directory exists
            if (!file_exists($backup_dir)) {
                wp_mkdir_p($backup_dir);
            }

            $timestamp   = date('Ymd_His');
            $site_backup = $backup_dir . "/site_backup_$timestamp.zip";
            $db_backup   = $backup_dir . "/db_backup_$timestamp.sql";

            // Normalize paths (important on Windows)
            $site_backup = str_replace('\\', '/', $site_backup);
            $db_backup   = str_replace('\\', '/', $db_backup);

            // Get requested type: db | files | both (default = both)
            $type = strtolower($req->get_param('type') ?? 'both');

            $results = [
                'db_backup'   => null,
                'site_backup' => null,
            ];

            // --------------------------
            // 1. Database Backup
            // --------------------------
            if ($type === 'db' || $type === 'both') {
                global $wpdb;
                $db_host = DB_HOST;
                $db_name = DB_NAME;
                $db_user = DB_USER;
                $db_pass = DB_PASSWORD;

                // Detect mysqldump path (Windows XAMPP or Linux)
                $mysqldump = 'mysqldump'; // default for Linux
                if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
                    $mysqldump = 'C:/xampp/mysql/bin/mysqldump.exe';
                }

                // Build safe command
                $command = "\"$mysqldump\" --user=\"{$db_user}\" --password=\"{$db_pass}\" --host=\"{$db_host}\" {$db_name} > \"{$db_backup}\"";

                // Execute
                exec($command, $output, $retval);

                if ($retval !== 0 || !file_exists($db_backup)) {
                    return new WP_Error('db_dump_failed', 'Database backup failed. Please check mysqldump path and DB credentials.');
                }

                $results['db_backup'] = $upload_dir['baseurl'] . '/laravel_backups/' . basename($db_backup);
            }

            // --------------------------
            // 2. Zip Files (wp-content only for safety)
            // --------------------------
            if ($type === 'files' || $type === 'both') {
                $root_path = ABSPATH . 'wp-content'; // safer: only wp-content
                $zip = new ZipArchive();

                if ($zip->open($site_backup, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
                    $files = new RecursiveIteratorIterator(
                        new RecursiveDirectoryIterator($root_path, FilesystemIterator::SKIP_DOTS),
                        RecursiveIteratorIterator::LEAVES_ONLY
                    );

                    foreach ($files as $file) {
                        if (!$file->isDir()) {
                            $filePath     = $file->getRealPath();
                            $relativePath = substr($filePath, strlen(ABSPATH));
                            $zip->addFile($filePath, $relativePath);
                        }
                    }
                    $zip->close();
                } else {
                    return new WP_Error('zip_failed', 'Could not create zip archive at ' . $site_backup);
                }

                $results['site_backup'] = $upload_dir['baseurl'] . '/backups/' . basename($site_backup);
            }

            // --------------------------
            // Return response
            // --------------------------
            return [
                'success' => true,
                'message' => ucfirst($type) . ' backup created successfully',
                'files'   => $results,
            ];
        } catch (\Exception $e) {
            return new WP_Error('backup_failed', $e->getMessage());
        }
    }




    public function handle_delete_backup(\WP_REST_Request $req)
    {
        try {
            $upload_dir = wp_upload_dir();
            $backup_dir = $upload_dir['basedir'] . '/laravel_backups';

            if (!file_exists($backup_dir)) {
                return [
                    'success' => true,
                    'message' => 'No backups found (backup folder does not exist).'
                ];
            }

            $deleted = 0;
            $failed  = 0;

            $files = glob($backup_dir . '/*'); // all files inside backups/
            if ($files) {
                foreach ($files as $file) {
                    if (is_file($file)) {
                        if (@unlink($file)) {
                            $deleted++;
                        } else {
                            $failed++;
                        }
                    }
                }
            }

            return [
                'success' => true,
                'message' => "Deleted {$deleted} backup(s). " . ($failed ? "$failed failed." : "All clear."),
            ];
        } catch (\Exception $e) {
            return new WP_Error('delete_failed', $e->getMessage());
        }
    }

    /**
     * Helper to produce consistent error responses.
     */
    private function error($code, $status = 400)
    {
        return new \WP_REST_Response(['error' => $code], $status);
    }
}

new Laravel_SSO_Bridge();
