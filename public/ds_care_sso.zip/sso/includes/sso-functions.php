<?php
/**
 * Helper functions and API wrappers for DS Care SSO plugin.
 */

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Get plugin instance from globals.
 * @return false|Laravel_SSO_Bridge
 */
function ds_care_get_plugin()
{
	if (!empty($GLOBALS['laravel_sso_bridge']) && is_object($GLOBALS['laravel_sso_bridge'])) {
		return $GLOBALS['laravel_sso_bridge'];
	}
	return false;
}

function ds_care_rest_ok($data = [], $status = 200)
{
	return new WP_REST_Response($data, $status);
}

function ds_care_rest_error($code = 'error', $status = 400)
{
	return new WP_REST_Response(['error' => $code], $status);
}

// Backup runner (if still used elsewhere)
if (!function_exists('sso_run_backup_function')) {
	function sso_run_backup_function($type, $timestamp)
	{
		$upload_dir = wp_upload_dir();
		$backup_dir = $upload_dir['basedir'] . '/laravel_backups';
		$status_file = $backup_dir . "/status.json";
		if (!file_exists($backup_dir)) {
			wp_mkdir_p($backup_dir);
		}

		$backup_file = $backup_dir . "/backup_{$type}_{$timestamp}.zip";

		try {
			$zip = new ZipArchive();
			if ($zip->open($backup_file, ZipArchive::CREATE) !== TRUE) {
				throw new Exception('Cannot create zip file');
			}

			// Database
			if ($type == 'db' || $type == 'both') {
				global $wpdb;
				$db_file = $backup_dir . "/db_{$timestamp}.sql";
				$cmd = sprintf(
					'mysqldump --user=%s --password=%s --host=%s %s > %s',
					DB_USER,
					DB_PASSWORD,
					DB_HOST,
					DB_NAME,
					$db_file
				);
				system($cmd);
				if (file_exists($db_file)) {
					$zip->addFile($db_file, basename($db_file));
				}
			}

			// Files
			if ($type == 'files' || $type == 'both') {
				$root_path = realpath(ABSPATH);
				$iterator = new RecursiveIteratorIterator(
					new RecursiveDirectoryIterator($root_path),
					RecursiveIteratorIterator::LEAVES_ONLY
				);
				foreach ($iterator as $file) {
					if (!$file->isDir()) {
						$filePath = $file->getRealPath();
						$relativePath = substr($filePath, strlen($root_path) + 1);
						$zip->addFile($filePath, $relativePath);
					}
				}
			}

			$zip->close();

			file_put_contents($status_file, json_encode([
				'status' => 'completed',
				'type' => $type,
				'started_at' => $timestamp,
				'completed_at' => date('Y-m-d H:i:s'),
				'file' => basename($backup_file)
			]));
		} catch (Exception $e) {
			file_put_contents($status_file, json_encode([
				'status' => 'failed',
				'type' => $type,
				'started_at' => $timestamp,
				'completed_at' => date('Y-m-d H:i:s'),
				'file' => null,
				'error' => $e->getMessage()
			]));
		}
	}
	add_action('sso_run_backup', 'sso_run_backup_function', 10, 2);
}

// --- API wrappers: delegate to class methods ---
function ds_care_api_login(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->handle_login($request);
}

function ds_care_api_check_plugin(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->check_plugin_status($request);
}

function ds_care_api_check_login(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->check_login_credentials($request);
}

function ds_care_api_add_secret(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->handle_token($request);
}

function ds_care_api_update_secret(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->handle_update_token($request);
}

function ds_care_api_status(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->handle_status($request);
}

function ds_care_api_wp_security_report(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->wp_security_report($request);
}

function ds_care_api_manage_users(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->manage_users($request);
}

function ds_care_api_handle_backup(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->handle_backup($request);
}

function ds_care_api_check_backup_status(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->check_backup_status($request);
}

function ds_care_api_delete_backup(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->handle_delete_backup($request);
}

function ds_care_api_db_optimize_data(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->wp_db_optimizer_status($request);
}

function ds_care_api_db_optimize_action(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->wp_db_optimizer_action($request);
}

function ds_care_api_site_ssl_details(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->get_ssl_certificate_details($request);
}

function ds_care_api_upgrade(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->update_item($request);
}

function ds_care_api_send_to_laravel(WP_REST_Request $request)
{
	$p = ds_care_get_plugin();
	if (!$p) return ds_care_rest_error('no_plugin', 500);
	return $p->send_backup_to_laravel($request);
}

