<?php
// Route registration extracted from sso.php to keep file smaller and more focused.
// Exposes a single function: register_laravel_sso_routes($instance)

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register the Laravel SSO Bridge REST routes.
 *
 * $instance should be the plugin instance (Laravel_SSO_Bridge) so callbacks
 * remain [$instance, 'methodName'] and continue to work.
 */
function register_laravel_sso_routes($instance)
{
    if (!isset($instance)) {
        return;
    }

    $ns = defined('\Laravel_SSO_Bridge::ROUTE_NS') ? \Laravel_SSO_Bridge::ROUTE_NS : 'laravel-sso/v1';

    register_rest_route($ns, '/login', [
        'methods' => ['GET', 'POST'],
        'callback' => [$instance, 'handle_login'],
        'permission_callback' => '__return_true',
    ]);

    register_rest_route($ns, '/check-plugin', [
        'methods' => ['GET', 'POST'],
        'callback' => [$instance, 'check_plugin_status'],
        'permission_callback' => '__return_true',
    ]);

    register_rest_route($ns, '/check-login', [
        'methods' => ['GET', 'POST'],
        'callback' => [$instance, 'check_login_credentials'],
        'permission_callback' => '__return_true',
    ]);

    register_rest_route($ns, '/add-secret-token', [
        'methods' => ['GET', 'POST'],
        'callback' => [$instance, 'handle_token'],
        'permission_callback' => '__return_true',
    ]);

    register_rest_route($ns, '/update-secret-token', [
        'methods' => ['GET', 'POST'],
        'callback' => [$instance, 'handle_update_token'],
        'permission_callback' => '__return_true',
    ]);

    register_rest_route($ns, '/status', [
        'methods' => ['GET'],
        'callback' => [$instance, 'handle_status'],
        'permission_callback' => '__return_true',
    ]);

    register_rest_route($ns, '/wp-security-report', [
        'methods' => ['GET'],
        'callback' => [$instance, 'wp_security_report'],
        'permission_callback' => '__return_true',
    ]);

    register_rest_route($ns, '/manage_users', [
        'methods' => ['GET'],
        'callback' => [$instance, 'manage_users'],
        'permission_callback' => [$instance, 'check_auth'],
    ]);

    register_rest_route($ns, '/handle_backup', [
        'methods' => ['GET'],
        'callback' => [$instance, 'handle_backup'],
        'permission_callback' => '__return_true',
    ]);

    register_rest_route($ns, '/check-backup-status', [
        'methods'  => 'GET',
        'callback' => [$instance, 'check_backup_status'],
        'permission_callback' => [$instance, 'check_auth'],
    ]);

    register_rest_route($ns, '/delete-backup', [
        'methods' => ['GET'],
        'callback' => [$instance, 'handle_delete_backup'],
        'permission_callback' => '__return_true',
    ]);

    register_rest_route($ns, '/db-optimize-data', [
        'methods' => ['GET'],
        'callback' => [$instance, 'wp_db_optimizer_status'],
        'permission_callback' => '__return_true',
    ]);

    register_rest_route($ns, '/db-optimize-action', [
        'methods' => ['GET'],
        'callback' => [$instance, 'wp_db_optimizer_action'],
        'permission_callback' => '__return_true',
    ]);

    register_rest_route($ns, '/site-ssl-details', [
        'methods' => ['GET'],
        'callback' => [$instance, 'get_ssl_certificate_details'],
        'permission_callback' => '__return_true',
    ]);

    register_rest_route($ns, '/upgrade', [
        'methods' =>  ['GET'],
        'callback' => [$instance, 'update_item'],
        'permission_callback' => '__return_true',
    ]);

    register_rest_route($ns, '/send-to-laravel', [
        'methods'  => ['GET'],
        'callback' => [$instance, 'send_backup_to_laravel'],
        'permission_callback' => '__return_true',
    ]);
}
