<?php

/**
 * Plugin Name: DS Care
 * Description: Dotsource Care plugin for SSO + site status — defensive so it won't bring the site down.
 * Version: 0.3.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class Laravel_SSO_Bridge
{
    const OPTION_KEY = 'laravel_sso_bridge_sites'; // array of [aud_base_url => secret]
    const ROUTE_NS = 'laravel-sso/v1';

    public function __construct()
    {
        // Register REST routes on rest_api_init
        add_action('rest_api_init', [$this, 'register_routes']);

        add_action('rest_api_init', function () {
            remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');
            add_filter('rest_pre_serve_request', function ($value) {
                header('Access-Control-Allow-Origin: *');
        header( 'Access-Control-Allow-Methods: GET, POST, OPTIONS' );
        header( 'Access-Control-Allow-Headers: Authorization, Content-Type, iss, secret' );
                if ('OPTIONS' === $_SERVER['REQUEST_METHOD']) {
                    status_header(200);
                    exit();
                }
                return $value;
            });
        });

        // Admin page and form handler
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_menu', [$this, 'main_menu_page']);
        add_action('admin_post_laravel_sso_save', [$this, 'save_settings']);
    }
    /**
     * Add main menu page (Welcome page)
     */
    public function main_menu_page()
    {
        add_menu_page(
            'DS Care Welcome',
            'DS Care',
            'manage_options',
            'ds-care-welcome',
            [$this, 'welcome_page'],
            'dashicons-shield-alt',
            2
        );
    }

    /**
     * Render the Welcome page with a beautiful design
     */
    public function welcome_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <style>
            .ds-care-welcome {
                background: linear-gradient(135deg, #f48120 0%, #ffcd6f 100%);
                color: #222;
                border-radius: 20px;
                padding: 48px 32px 36px 32px;
                margin: 48px auto;
                box-shadow: 0 10px 36px rgba(60, 60, 100, 0.14);
                font-family: 'Segoe UI', 'Arial', sans-serif;
                max-width: 900px;
                border: 1.5px solid #fbbf24;
            }

            .ds-care-welcome h1 {
                font-size: 2.7em;
                color: #1a365d;
                margin-bottom: 0.2em;
                letter-spacing: -1px;
            }

            .ds-care-welcome .ds-logo {
                width: 90px;
                height: 90px;
                border-radius: 50%;
                background: #fff;
                background-size: 70px 70px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 24px;
                box-shadow: 0 3px 12px rgba(0, 0, 0, 0.10);
                position: relative;
                overflow: hidden;
            }

            .ds-care-welcome .ds-logo .dashicons {
                position: relative;
                z-index: 2;
                text-shadow: 0 2px 8px rgba(0, 0, 0, 0.10);
            }

            .ds-care-welcome .ds-info {
                font-size: 1.25em;
                margin-bottom: 1.7em;
                color: #234e52;
                background: rgba(255, 255, 255, 0.7);
                border-radius: 8px;
                padding: 10px 18px;
                box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04);
            }

            .ds-care-welcome .ds-features {
                display: flex;
                flex-wrap: wrap;
                gap: 28px;
                margin-bottom: 2.2em;
            }

            .ds-care-welcome .ds-feature {
                flex: 1 1 220px;
                background: #fff;
                border-radius: 14px;
                padding: 28px 20px;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.07);
                text-align: center;
                min-width: 200px;
                transition: transform 0.15s, box-shadow 0.15s;
                border: 1px solid #fbbf24;
            }

            .ds-care-welcome .ds-feature:hover {
                transform: translateY(-4px) scale(1.03);
                box-shadow: 0 6px 24px rgba(60, 60, 100, 0.13);
            }

            .ds-care-welcome .ds-feature h3 {
                color: #2563eb;
                margin-bottom: 0.5em;
                font-size: 1.18em;
            }

            .ds-care-welcome .ds-footer {
                text-align: right;
                color: #234e52;
                font-size: 1.08em;
                margin-top: 2.2em;
            }

            @media (max-width: 900px) {
                .ds-care-welcome {
                    padding: 24px 5px;
                }

                .ds-care-welcome .ds-features {
                    flex-direction: column;
                    gap: 14px;
                }
            }
        </style>
        <div class="ds-care-welcome">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
                <div class="ds-logo">
                    <span class="dashicons dashicons-shield-alt" style="font-size:48px;color:#f28628;"></span>
                </div>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSVa7IBlV184mNUtcWKfeTFDHmcsYRTuVLlw2weRSOYVgrFnWZPoLZldukYeyWdxQcBog&usqp=CAU" alt="Brand Logo" style="height:64px;width:auto;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.10);background:#fff;object-fit:contain;max-width:180px;padding: 0px 15px;" />
            </div>
            <h1>Welcome to DS Care</h1>
            <div class="ds-info">
                <strong>DS Care</strong> is your all-in-one WordPress SSO, security, and site health plugin.<br>
                Secure, monitor, and manage your site with confidence.
            </div>
            <div class="ds-features">
                <div class="ds-feature"><span class="dashicons dashicons-unlock" style="font-size:32px;color:#10b981;"></span>
                    <h3>Single Sign-On (SSO)</h3>
                    <p>Seamless and secure login integration with your Laravel hub.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-shield" style="font-size:32px;color:#f59e42;"></span>
                    <h3>Site Status</h3>
                    <p>Monitor plugins, themes, users, and WordPress health at a glance.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-backup" style="font-size:32px;color:#6366f1;"></span>
                    <h3>Backups</h3>
                    <p>Easy, on-demand site and database backup for peace of mind.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-admin-users" style="font-size:32px;color:#ef4444;"></span>
                    <h3>User Management</h3>
                    <p>Quickly view and manage your site's users and roles.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-shield-alt" style="font-size:32px;color:#0ea5e9;"></span>
                    <h3>Malware Scans</h3>
                    <p>Scan your site for malware and threats automatically.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-clock" style="font-size:32px;color:#fbbf24;"></span>
                    <h3>Scan Frequency</h3>
                    <p>Set how often your site is scanned for threats.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-shield" style="font-size:32px;color:#6366f1;"></span>
                    <h3>Real-Time Firewall</h3>
                    <p>Block malicious traffic in real time with a smart firewall.</p>
                </div>

                <div class="ds-feature"><span class="dashicons dashicons-visibility" style="font-size:32px;color:#a21caf;"></span>
                    <h3>Bot Protection</h3>
                    <p>Stop bad bots from abusing your site and resources.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-search" style="font-size:32px;color:#0ea5e9;"></span>
                    <h3>Vulnerability Scanner</h3>
                    <p>Scan for plugin, theme, and core vulnerabilities.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-search" style="font-size:32px;color:#f59e42;"></span>
                    <h3>Website Audit</h3>
                    <p>Get a full audit of your website’s health and security.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-format-image" style="font-size:32px;color:#f59e42;"></span>
                    <h3>Visual Regression</h3>
                    <p>Detect visual changes after updates or deployments.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-controls-repeat" style="font-size:32px;color:#6366f1;"></span>
                    <h3>Safe Updates</h3>
                    <p>Test updates in a safe environment before applying.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-list-view" style="font-size:32px;color:#0ea5e9;"></span>
                    <h3>WP Activity Logs</h3>
                    <p>Track all important actions and changes on your site.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-dashboard" style="font-size:32px;color:#f59e42;"></span>
                    <h3>Uptime Monitoring</h3>
                    <p>Get notified if your website goes down.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-admin-site-alt" style="font-size:32px;color:#10b981;"></span>
                    <h3>Domain Monitoring</h3>
                    <p>Monitor your domain’s status and expiration.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-visibility" style="font-size:32px;color:#6366f1;"></span>
                    <h3>Visual Monitoring</h3>
                    <p>Monitor your site’s appearance and detect unwanted changes.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-warning" style="font-size:32px;color:#ef4444;"></span>
                    <h3>PHP Error Monitoring</h3>
                    <p>Catch and log PHP errors in real time.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-lock" style="font-size:32px;color:#2563eb;"></span>
                    <h3>SSL Monitoring</h3>
                    <p>Ensure your SSL certificate is always valid and secure.</p>
                </div>
                <div class="ds-feature"><span class="dashicons dashicons-email" style="font-size:32px;color:#0ea5e9;"></span>
                    <h3>Email Support</h3>
                    <p>Get fast, expert help when you need it.</p>
                </div>
            </div>
            <div class="ds-footer">
                <em>Version 0.3.0 &mdash; Crafted with <span style="color:#e53e3e;">&hearts;</span> by Dotsource</em>
            </div>
        </div>
    <?php
    }

    public function register_routes()
    {
        // Delegate route registration to a separate file so this class stays focused.
        $routes_file = plugin_dir_path(__FILE__) . 'api-routes.php';
        if (file_exists($routes_file)) {
            require_once $routes_file;
            if (function_exists('register_laravel_sso_routes')) {
                register_laravel_sso_routes($this);
            }
        }
    }


    function check_plugin_status(WP_REST_Request $request)
    {
        $plugin = 'sso/sso.php'; // e.g. "woocommerce/woocommerce.php"

        if (empty($plugin)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Plugin parameter is required.'
            ], 400);
        }

        $is_active = is_plugin_active($plugin);

        return [
            'success' => true,
            'plugin'  => $plugin,
            'active'  => $is_active,
        ];
    }


    function check_login_credentials(WP_REST_Request $request)
    {
        $username_or_email = sanitize_text_field($request->get_param('username'));
        $password = $request->get_param('password');

        if (empty($username_or_email) || empty($password)) {
            return new WP_REST_Response(['status' => 'error', 'message' => 'Missing credentials'], 400);
        }

        // Allow login by email or username
        if (is_email($username_or_email)) {
            $user = get_user_by('email', $username_or_email);
        } else {
            $user = get_user_by('login', $username_or_email);
        }

        if (!$user) {
            return new WP_REST_Response(['status' => 'error', 'message' => 'User not found with that username and Email'], 404);
        }

        // Validate password
        if (wp_check_password($password, $user->user_pass, $user->ID)) {

            return new WP_REST_Response([
                'success' => true,
                'message' => 'User authenticated successfully',
                'data' => [
                    'username'  => $user->user_login,
                ],
            ], 200);
        } else {
            return new WP_REST_Response(['status' => 'error', 'message' => 'Password is not valid for this user'], 401);
        }
    }
    /**
     * Permission callback: verifies shared secret signature.
     * Expects 'iss' and 'sig' params (GET or POST).
     */
    public function check_auth($req)
    {
        try {
            $iss = $req->get_param('iss');
            $sig = $req->get_param('sig');

            if (empty($iss) || empty($sig)) {
                return false;
            }

            $map = get_option(self::OPTION_KEY, []);
            $iss = rtrim($iss, '/');

            if (!isset($map[$iss])) {
                return false;
            }

            $secret = $map[$iss];
            // compute signature: HMAC sha256 of iss, base64
            $calc = base64_encode(hash_hmac('sha256', $iss, $secret, true));

            // timing-safe comparison
            return hash_equals($calc, $sig);
        } catch (\Throwable $e) {
            error_log('laravel_sso_bridge::check_auth error: ' . $e->getMessage());
            return false;
        }
    }

    public function admin_menu()
    {
        add_options_page('DS Care', 'DS Care', 'manage_options', 'laravel-sso-bridge', [$this, 'settings_page']);
    }

    public function settings_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $map = get_option(self::OPTION_KEY, []);
    ?>
        <div class="wrap">
            <h1>DS Care</h1>
            <p>Add your Laravel hub base URL and shared secret (one row per hub). For most setups, you will have exactly one hub.</p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('laravel_sso_save'); ?>
                <input type="hidden" name="action" value="laravel_sso_save" />
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>Laravel Hub Base URL (iss)</th>
                            <th>Shared Secret</th>
                        </tr>
                    </thead>
                    <tbody id="laravel-sso-rows">
                        <?php if (!empty($map) && is_array($map)): ?>
                            <?php foreach ($map as $iss => $secret): ?>
                                <tr>
                                    <td><input style="width:100%" name="iss[]" value="<?php echo esc_attr($iss); ?>"></td>
                                    <td><input style="width:100%" name="secret[]" value="<?php echo esc_attr($secret); ?>"></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        <tr>
                            <td><input style="width:100%" name="iss[]" placeholder="https://laravel-hub.example.com"></td>
                            <td><input style="width:100%" name="secret[]" placeholder="paste secret from Laravel site record"></td>
                        </tr>
                    </tbody>
                </table>
                <p><button class="button button-primary">Save</button></p>
            </form>
        </div>
<?php
    }

    /**
     * Save settings (admin_post)
     */
    public function save_settings()
    {
        if (!current_user_can('manage_options')) {
            wp_die('forbidden', '', ['response' => 403]);
        }
        check_admin_referer('laravel_sso_save');

        $iss = isset($_POST['iss']) ? array_map('sanitize_text_field', (array)$_POST['iss']) : [];
        $sec = isset($_POST['secret']) ? array_map('sanitize_text_field', (array)$_POST['secret']) : [];

        $map = [];
        foreach ($iss as $i => $val) {
            $val = rtrim($val, '/');
            if ($val && !empty($sec[$i])) {
                $map[$val] = $sec[$i];
            }
        }

        update_option(self::OPTION_KEY, $map);
        wp_redirect(admin_url('options-general.php?page=laravel-sso-bridge&updated=1'));
        exit; // safe here — final in admin_post flow
    }

    /**
     * Save a single credential pair — does NOT exit.
     * Returns true on success, WP_Error on failure.
     */
    public function save_creds($url, $token)
    {
        try {
            if (empty($url) || empty($token)) {
                return new WP_Error('invalid_input', 'url and token required', ['status' => 400]);
            }

            $iss = rtrim(sanitize_text_field($url), '/');
            $sec = sanitize_text_field($token);

            if (empty($iss) || empty($sec)) {
                return new WP_Error('invalid_input', 'invalid url or token after sanitization', ['status' => 400]);
            }

            // Merge with existing entries instead of overwriting everything
            $map = get_option(self::OPTION_KEY, []);
            if (!is_array($map)) {
                $map = [];
            }

            // Support multiple tokens per issuer. Keep existing tokens and append if different.
            $existing = $map[$iss] ?? null;
            if ($existing === null) {
                // store as single string for backward compatibility
                $map[$iss] = $sec;
            } else {
                // if existing is a string, convert to array
                if (!is_array($existing)) {
                    if ($existing === $sec) {
                        // identical token already present — nothing to do
                    } else {
                        $map[$iss] = [$existing, $sec];
                    }
                } else {
                    // array of tokens — append if it's not present
                    if (!in_array($sec, $existing, true)) {
                        $existing[] = $sec;
                        $map[$iss] = $existing;
                    }
                }
            }

            update_option(self::OPTION_KEY, $map);
            return true;
        } catch (\Throwable $e) {
            error_log('laravel_sso_bridge::save_creds error: ' . $e->getMessage());
            return new WP_Error('save_failed', 'failed to save credentials', ['status' => 500]);
        }
    }

    public function update_creds($url, $token)
    {
        try {
            if (empty($url) || empty($token)) {
                return new WP_Error('invalid_input', 'url and token required', ['status' => 400]);
            }

            $iss = rtrim(sanitize_text_field($url), '/');
            $sec = sanitize_text_field($token);

            if (empty($iss) || empty($sec)) {
                return new WP_Error('invalid_input', 'invalid url or token after sanitization', ['status' => 400]);
            }

            $map = get_option(self::OPTION_KEY, []);
            if (!is_array($map)) {
                $map = [];
            }

            if (!isset($map[$iss])) {
                return new WP_Error('not_found', 'issuer not found, cannot update', ['status' => 404]);
            }

            $existing = $map[$iss] ?? null;
            if ($existing === null) {
                return new WP_Error('not_found', 'issuer not found, cannot update', ['status' => 404]);
            }

            // If existing is array, update/append
            if (is_array($existing)) {
                if (!in_array($sec, $existing, true)) {
                    $existing[] = $sec;
                }
                $map[$iss] = $existing;
            } else {
                // existing is string
                if ($existing === $sec) {
                    // same token — nothing to change
                    $map[$iss] = $existing;
                } else {
                    // convert to array holding both
                    $map[$iss] = [$existing, $sec];
                }
            }

            update_option(self::OPTION_KEY, $map);

            return true;
        } catch (\Throwable $e) {
            error_log('laravel_sso_bridge::update_creds error: ' . $e->getMessage());
            return new WP_Error('update_failed', 'failed to update credentials', ['status' => 500]);
        }
    }

    /**
     * Verify credentials passed in REST request against stored OPTION_KEY map.
     * Expects params 'url' and 'token' on the request. Returns true on success
     * or a WP_REST_Response (with appropriate status) on failure.
     */
    private function verify_creds(\WP_REST_Request $req)
    {
        try {
            // Require headers only: 'iss' and 'secret'
            $headers = $req->get_headers();

             $url = $headers['iss'][0] ?? null;
            $token = $headers['secret'][0] ?? null;

            if (empty($url) || empty($token)) {
                return new \WP_REST_Response(['error' => 'missing_headers', 'message' => "Required headers missing: Authonticated headers"], 400);
            }

            $iss = rtrim(sanitize_text_field($url), '/');
            $sec = sanitize_text_field($token);

            if (empty($iss) || empty($sec)) {
                return new \WP_REST_Response(['error' => 'invalid_params', 'message' => 'invalid url or token after sanitization'], 400);
            }

            $map = get_option(self::OPTION_KEY, []);
            if (!is_array($map) || !isset($map[$iss])) {
                return new \WP_REST_Response(['error' => 'unknown_issuer', 'message' => 'issuer not found'], 404);
            }

            $saved = $map[$iss];
            // support single string or array of tokens
             if (is_array($saved)) {
                foreach ($saved as $s) {
                   $expected = base64_encode(hash_hmac('sha256', $iss, $s, true));
                    if (hash_equals($expected, $sec)) {
                        return true;
                    }
                }
                return new \WP_REST_Response(['error' => 'bad_token', 'message' => 'token not accepted for issuer'], 403);
            }

            if (hash_equals($saved, $sec)) {
                return true;
            }

            return new \WP_REST_Response(['error' => 'bad_token', 'message' => 'token not accepted for issuer'], 403);
        } catch (\Throwable $e) {
            error_log('laravel_sso_bridge::verify_creds error: ' . $e->getMessage());
            return new \WP_REST_Response(['error' => 'internal_error', 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Add secret/token via REST endpoint. GET/POST allowed.
     * Params: url, token
     */
    public function handle_token(\WP_REST_Request $req)
    {
        try {
            $url = $req->get_param('url');
            $token = $req->get_param('token');

            if (empty($url) || empty($token)) {
                return new \WP_REST_Response(['error' => 'missing_params'], 400);
            }

            $res = $this->save_creds($url, $token);
            if (is_wp_error($res)) {
                $code = $res->get_error_code();
                $msg = $res->get_error_message();
                $status = $res->get_error_data()['status'] ?? 500;
                return new \WP_REST_Response(['error' => $code, 'message' => $msg], $status);
            }

            return new \WP_REST_Response(['status' => 'saved'], 200);
        } catch (\Throwable $e) {
            error_log('laravel_sso_bridge::handle_token error: ' . $e->getMessage());
            return new \WP_REST_Response(['error' => 'internal_error', 'message' => $e->getMessage()], 500);
        }
    }

    public function handle_update_token(\WP_REST_Request $req)
    {
        try {
            $url = $req->get_param('url');
            $token = $req->get_param('token');

            if (empty($url) || empty($token)) {
                return new \WP_REST_Response(['error' => 'missing_params'], 400);
            }

            $res = $this->update_creds($url, $token);
            if (is_wp_error($res)) {
                $code = $res->get_error_code();
                $msg = $res->get_error_message();
                $status = $res->get_error_data()['status'] ?? 500;
                return new \WP_REST_Response(['error' => $code, 'message' => $msg], $status);
            }

            return new \WP_REST_Response(['status' => 'saved'], 200);
        } catch (\Throwable $e) {
            error_log('laravel_sso_bridge::handle_token error: ' . $e->getMessage());
            return new \WP_REST_Response(['error' => 'internal_error', 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Handle login request
     * Expects payload (JSON string), sig, optional redirect
     */
    public function handle_login(\WP_REST_Request $req)
    {
        try {
            $payload  = $req->get_param('payload');
            $sig      = $req->get_param('sig');
            $redirect = $req->get_param('redirect');

            if (empty($payload) || empty($sig)) {
                return $this->error('missing_params', 400);
            }

            $data = json_decode($payload, true);
            if (!$data || !is_array($data)) {
                return $this->error('bad_payload', 400);
            }

            $iss   = isset($data['iss']) ? rtrim($data['iss'], '/') : '';
            $aud   = isset($data['aud']) ? rtrim($data['aud'], '/') : '';
            $email = $data['email'];

            $exp   = isset($data['exp']) ? intval($data['exp']) : 0;
            $nonce = isset($data['nonce']) ? sanitize_text_field($data['nonce']) : '';

            if (!$iss || !$aud || !$email || !$exp || !$nonce) {
                return $this->error('missing_claims', 400);
            }

            if ($aud !== rtrim(get_site_url(), '/')) {
                return $this->error('aud_mismatch', 400);
            }

            $map = get_option(self::OPTION_KEY, []);
            if (!isset($map[$iss])) {
                return $this->error('unknown_issuer', 400);
            }

            $secret_or_list = $map[$iss];
            $sig_ok = false;
            if (is_array($secret_or_list)) {
                foreach ($secret_or_list as $secret_item) {
                    $calc = base64_encode(hash_hmac('sha256', $payload, $secret_item, true));
                    if (hash_equals($calc, $sig)) {
                        $sig_ok = true;
                        break;
                    }
                }
            } else {
                $calc = base64_encode(hash_hmac('sha256', $payload, $secret_or_list, true));
                if (hash_equals($calc, $sig)) {
                    $sig_ok = true;
                }
            }

            if (!$sig_ok) {
                return $this->error('bad_signature', 400);
            }

            if (time() > $exp) {
                return $this->error('expired', 400);
            }

            // prevent immediate replay by transient (short TTL)
            $tkey = 'laravel_sso_used_' . md5($nonce);
            if (get_transient($tkey)) {
                return $this->error('replayed', 400);
            }
            set_transient($tkey, 1, 5 * MINUTE_IN_SECONDS);
            if (is_email($email)) {
                error_log('SSO Debug - Trying email login');
                $user = get_user_by('email', $email);
            }
            if (!$user) {
                error_log('SSO Debug - Trying username login');
                $user = get_user_by('login', $email);
            }
            if (!$user) {
                error_log('SSO Error: User not found for login: ' . $email);
                return new \WP_REST_Response([
                    'status' => false,
                    'error' => 'user_not_found',
                    'message' => 'User account not found'
                ], 403);
            }

            if (!in_array('administrator', (array) $user->roles, true)) {
                return $this->error('not_admin', 403);
            }

            // ✅ Login the admin user
            wp_set_current_user($user->ID);
            wp_set_auth_cookie($user->ID, true);

            // ✅ Handle redirect
            $dest     = $redirect ? esc_url_raw($redirect) : admin_url();
            $site_url = rtrim(get_site_url(), '/');
            if (strpos($dest, $site_url) !== 0) {
                $dest = admin_url();
            }

            wp_safe_redirect($dest);
            exit;
        } catch (\Throwable $e) {
            error_log('laravel_sso_bridge::handle_login error: ' . $e->getMessage());
            return $this->error('internal_error', 500);
        }
    }


    /**
     * Status endpoint — defensive: checks function existence and catches exceptions.
     * Requires check_auth permission callback to pass.
     */
    public function handle_status(\WP_REST_Request $req)
    {
        // Verify credentials for this API call
        $cred_check = $this->verify_creds($req);
        if ($cred_check !== true) {
            return $cred_check;
        }
        try {
            // Load plugin/theme/update functions safely
            $wp_admin_path = ABSPATH . 'wp-admin/includes';
            try {
                if (!function_exists('get_plugins') && file_exists($wp_admin_path . '/plugin.php')) {
                    require_once $wp_admin_path . '/plugin.php';
                }
                if (!function_exists('get_plugin_updates') && file_exists($wp_admin_path . '/update.php')) {
                    require_once $wp_admin_path . '/update.php';
                }
                if (!function_exists('wp_get_themes') && file_exists($wp_admin_path . '/theme.php')) {
                    require_once $wp_admin_path . '/theme.php';
                }
            } catch (\Throwable $e) {
                error_log('handle_status include failed: ' . $e->getMessage());
            }

            global $wp_version;

            // 🔹 WP update check
            $wp_update = null;
            try {
                if (function_exists('wp_version_check')) {
                    wp_version_check();
                }
                $updates = function_exists('get_core_updates') ? get_core_updates() : [];
                if (is_array($updates) && isset($updates[0]->current)) {
                    $wp_update = $updates[0]->current;
                }
            } catch (\Throwable $inner) {
                error_log('handle_status wp update failed: ' . $inner->getMessage());
            }

            // 🔹 Plugins
            $plugins        = function_exists('get_plugins') ? (array) get_plugins() : [];
            $active_plugins = (array) get_option('active_plugins', []);
            $plugin_updates = function_exists('get_plugin_updates') ? (array) get_plugin_updates() : [];

            $plugin_items = [];
            foreach ($plugins as $path => $details) {
                try {
                    $is_active    = in_array($path, $active_plugins, true);
                    $update_avail = $plugin_updates[$path] ?? null;

                    // Icon detection
                    $icon_url = 'https://s.w.org/plugins/geopattern-icon.png';
                    if ($update_avail && isset($update_avail->update->icons) && is_array($update_avail->update->icons)) {
                        $icons = $update_avail->update->icons;
                        $icon_url = $icons['svg'] ?? $icons['2x'] ?? $icons['1x'] ?? $icons['default'] ?? $icon_url;
                    }

                    $plugin_items[] = [
                        'name'       => $details['Name'] ?? 'unknown',
                        'version'    => $details['Version'] ?? 'unknown',
                        'author'     => $details['Author'] ?? '',
                        'plugin_uri' => $details['PluginURI'] ?? '',
                        'file_path'  => $path,
                        'is_active'  => $is_active,
                        'icon_url'   => $icon_url,
                        'update'     => $update_avail ? [
                            'new_version' => $update_avail->update->new_version ?? null,
                            'package'     => $update_avail->package ?? null,
                            'slug'        => $update_avail->update->slug ?? null,
                        ] : null,
                    ];
                } catch (\Throwable $e) {
                    error_log('handle_status plugin parse failed: ' . $e->getMessage());
                }
            }

            // 🔹 Themes
            $themes        = function_exists('wp_get_themes') ? (array) wp_get_themes() : [];
            $current_theme = function_exists('wp_get_theme') ? wp_get_theme() : null;

            $theme_items = [];
            foreach ($themes as $slug => $theme) {
                try {
                    $theme_items[] = [
                        'name'       => $theme->get('Name') ?: 'unknown',
                        'version'    => $theme->get('Version') ?: 'unknown',
                        'author'     => $theme->get('Author') ?: '',
                        'theme_uri'  => $theme->get('ThemeURI') ?: '',
                        'slug'       => $slug,
                        'is_active'  => ($current_theme && $theme->get_stylesheet() === $current_theme->get_stylesheet()),
                        'screenshot' => $theme->get_screenshot() ?: 'https://s.w.org/style/images/about/WordPress-logotype-wmark.png',
                    ];
                } catch (\Throwable $e) {
                    error_log('handle_status theme parse failed: ' . $e->getMessage());
                }
            }

            // 🔹 Users
            $user_result = [];
            try {
                $users = function_exists('get_users') ? get_users() : [];
                foreach ($users as $user) {
                    $user_result[] = [
                        'id'       => $user->ID,
                        'username' => $user->user_login,
                        'email'    => $user->user_email,
                        'roles'    => $user->roles,
                        'name'     => $user->display_name,
                    ];
                }
            } catch (\Throwable $e) {
                error_log('handle_status users failed: ' . $e->getMessage());
            }

            $site_health_result = [];
            try {
                // Include necessary WordPress admin files
                if (!class_exists('WP_Site_Health')) {
                    require_once ABSPATH . 'wp-admin/includes/class-wp-site-health.php';
                }
                if (!function_exists('wp_check_php_version')) {
                    require_once ABSPATH . 'wp-admin/includes/misc.php';
                }

                if (class_exists('WP_Site_Health')) {
                    $site_health = new \WP_Site_Health();

                    // Get all available tests
                    $tests = $site_health->get_tests();

                    $direct_results = [];
                    $async_results = [];

                    // Execute direct tests dynamically with proper argument handling
                    if (!empty($tests['direct'])) {
                        foreach ($tests['direct'] as $test_name => $test_args) {
                            try {
                                $result = null;

                                if (isset($test_args['test'])) {
                                    $callback = $test_args['test'];

                                    // Handle method calls to WP_Site_Health instance
                                    if (is_string($callback) && method_exists($site_health, $callback)) {
                                        // Use reflection to check if method needs arguments
                                        $reflection = new \ReflectionMethod($site_health, $callback);
                                        $params = $reflection->getParameters();

                                        if (count($params) === 0) {
                                            $result = $site_health->$callback();
                                        } else {
                                            // Skip tests that require specific arguments we don't have
                                            continue;
                                        }
                                    }
                                    // Handle array callbacks [class, method]
                                    elseif (is_array($callback) && count($callback) === 2) {
                                        list($class, $method) = $callback;

                                        if ($class === $site_health || $class === 'WP_Site_Health') {
                                            $reflection = new \ReflectionMethod($site_health, $method);
                                            $params = $reflection->getParameters();

                                            if (count($params) === 0) {
                                                $result = $site_health->$method();
                                            }
                                        } elseif (is_callable($callback)) {
                                            // Check if callable needs arguments
                                            try {
                                                $reflection = new \ReflectionFunction($callback);
                                                if ($reflection->getNumberOfRequiredParameters() === 0) {
                                                    $result = call_user_func($callback);
                                                }
                                            } catch (\Exception $e) {
                                                // Skip if we can't reflect
                                                continue;
                                            }
                                        }
                                    }
                                    // Handle direct function calls
                                    elseif (is_callable($callback)) {
                                        try {
                                            if (is_string($callback) && function_exists($callback)) {
                                                $reflection = new \ReflectionFunction($callback);
                                                if ($reflection->getNumberOfRequiredParameters() === 0) {
                                                    $result = call_user_func($callback);
                                                }
                                            } else {
                                                $result = call_user_func($callback);
                                            }
                                        } catch (\Exception $e) {
                                            continue;
                                        }
                                    }

                                    if (isset($result) && is_array($result)) {
                                        $direct_results[$test_name] = array_merge([
                                            'test' => $test_name,
                                            'label' => $test_args['label'] ?? ucwords(str_replace('_', ' ', $test_name))
                                        ], $result);
                                    }
                                }
                            } catch (\Throwable $test_error) {
                                // Log but don't include failed tests in results
                                error_log("Site health direct test '{$test_name}' failed: " . $test_error->getMessage());
                            }
                        }
                    }

                    // Handle async tests - force run some key ones that can run synchronously
                    if (!empty($tests['async'])) {
                        foreach ($tests['async'] as $test_name => $test_args) {
                            try {
                                $result = null;

                                // First check cached results
                                $transient_key = 'health-check-site-status-result';
                                $cached_results = get_transient($transient_key);

                                if (is_array($cached_results) && isset($cached_results[$test_name])) {
                                    $result = $cached_results[$test_name];
                                } else {
                                    // Try to run specific async tests that we can execute immediately
                                    switch ($test_name) {
                                        case 'dotorg_communication':
                                            if (method_exists($site_health, 'get_test_dotorg_communication')) {
                                                $result = $site_health->get_test_dotorg_communication();
                                            }
                                            break;

                                        case 'https_status':
                                            if (method_exists($site_health, 'get_test_https_status')) {
                                                $result = $site_health->get_test_https_status();
                                            }
                                            break;

                                        case 'loopback_requests':
                                            if (method_exists($site_health, 'get_test_loopback_requests')) {
                                                $result = $site_health->get_test_loopback_requests();
                                            }
                                            break;

                                        case 'background_updates':
                                            if (method_exists($site_health, 'get_test_background_updates')) {
                                                $result = $site_health->get_test_background_updates();
                                            }
                                            break;

                                        case 'authorization_header':
                                            if (method_exists($site_health, 'get_test_authorization_header')) {
                                                $result = $site_health->get_test_authorization_header();
                                            }
                                            break;

                                        case 'page_cache':
                                            if (method_exists($site_health, 'get_test_page_cache')) {
                                                $result = $site_health->get_test_page_cache();
                                            }
                                            break;
                                    }
                                }

                                if (is_array($result)) {
                                    $async_results[$test_name] = array_merge([
                                        'test' => $test_name,
                                        'label' => $test_args['label'] ?? ucwords(str_replace('_', ' ', $test_name)),
                                        'async' => true
                                    ], $result);
                                }
                            } catch (\Throwable $test_error) {
                                error_log("Site health async test '{$test_name}' failed: " . $test_error->getMessage());
                            }
                        }
                    }

                    // Calculate dynamic summary
                    $summary = [
                        'critical' => 0,
                        'recommended' => 0,
                        'good' => 0,
                    ];

                    $all_results = array_merge($direct_results, $async_results);
                    foreach ($all_results as $test_result) {
                        if (!empty($test_result['status']) && isset($summary[$test_result['status']])) {
                            $summary[$test_result['status']]++;
                        }
                    }

                    // Get site health score dynamically
                    $site_health_score = null;
                    try {
                        $total_tests = count($all_results);
                        if ($total_tests > 0) {
                            $good_tests = $summary['good'];
                            $recommended_tests = $summary['recommended'];
                            $critical_tests = $summary['critical'];

                            // WordPress scoring: good = 100%, recommended = 50%, critical = 0%
                            $score = (($good_tests * 100) + ($recommended_tests * 50)) / $total_tests;
                            $site_health_score = round($score);
                        }
                    } catch (\Throwable $e) {
                        error_log('Site health score calculation failed: ' . $e->getMessage());
                    }

                    // Get system information dynamically
                    $info = [];
                    try {
                        // Get basic system info without debug_data if it's problematic
                        global $wpdb;

                        $info = [
                            'wp_version' => get_bloginfo('version'),
                            'php_version' => PHP_VERSION,
                            'php_sapi' => php_sapi_name(),
                            'memory_limit' => ini_get('memory_limit'),
                            'max_execution_time' => ini_get('max_execution_time'),
                            'upload_max_filesize' => ini_get('upload_max_filesize'),
                            'post_max_size' => ini_get('post_max_size'),
                            'mysql_version' => $wpdb->db_version(),
                            'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
                            'https_enabled' => is_ssl(),
                            'multisite' => is_multisite(),
                            'wp_debug' => defined('WP_DEBUG') && WP_DEBUG,
                            'wp_cache' => defined('WP_CACHE') && WP_CACHE,
                        ];
                    } catch (\Throwable $e) {
                        error_log('Site health system info failed: ' . $e->getMessage());
                    }

                    $site_health_result = [
                        'status_summary' => $summary,
                        'direct_tests' => $direct_results,
                        'async_tests' => $async_results,
                        'total_tests' => count($all_results),
                        'score' => $site_health_score,
                        'system_info' => $info,
                        'last_updated' => current_time('mysql'),
                        'has_critical_issues' => $summary['critical'] > 0,
                        'has_recommended_improvements' => $summary['recommended'] > 0,
                    ];
                }
            } catch (\Throwable $e) {
                error_log('handle_status site health failed: ' . $e->getMessage());
                $site_health_result = [
                    'error' => $e->getMessage(),
                    'fallback_info' => [
                        'php_version' => PHP_VERSION,
                        'wp_version' => get_bloginfo('version'),
                        'memory_limit' => ini_get('memory_limit'),
                        'https_enabled' => is_ssl(),
                        'last_updated' => current_time('mysql')
                    ]
                ];
            }

            // 🔹 Site Info
            $site_name        = function_exists('get_bloginfo') ? get_bloginfo('name') : 'unknown';
            $site_description = function_exists('get_bloginfo') ? get_bloginfo('description') : '';
            $site_url         = function_exists('get_site_url') ? get_site_url() : '';
            $meta_title       = get_option('blogname', $site_name);
            $meta_description = get_option('blogdescription', $site_description);

            // Site Logo
            $logo_url = null;
            try {
                if (function_exists('get_theme_mod') && function_exists('wp_get_attachment_image_url')) {
                    $logo_id = get_theme_mod('custom_logo');
                    if ($logo_id) {
                        $logo_url = wp_get_attachment_image_url($logo_id, 'full');
                    }
                }
            } catch (\Throwable $e) {
                error_log('handle_status logo fetch failed: ' . $e->getMessage());
            }

            // User counts
            $counts      = function_exists('count_users') ? count_users() : ['total_users' => 0, 'avail_roles' => []];
            $admin_count = $counts['avail_roles']['administrator'] ?? 0;

            // 🔹 Final Payload
            $payload = [
                "site_name"                  => $site_name,
                "site_logo_url"              => $logo_url,
                "wordpress_version"          => $wp_version ?? 'unknown',
                "php_version"                => phpversion(),
                "wordpress_update_available" => $wp_update,
                "icon_url"                   => "https://s.w.org/style/images/about/WordPress-logotype-simplified.png",
                'site_health'               => $site_health_result,
                "site" => [
                    "name"            => $site_name,
                    "description"     => $site_description,
                    "url"             => $site_url,
                    "meta_title"      => $meta_title,
                    "meta_description" => $meta_description,
                ],
                "plugins" => [
                    "total"   => count($plugins),
                    "active"  => count($active_plugins),
                    "updates" => count($plugin_updates),
                    "items"   => $plugin_items,
                ],
                "themes" => [
                    "total"   => count($themes),
                    "current" => $current_theme ? $current_theme->get('Name') : 'unknown',
                    "items"   => $theme_items,
                ],
                "users" => [
                    "total"  => $counts['total_users'] ?? 0,
                    "admins" => $admin_count,
                    "items"  => $user_result,
                ],
                // Reserved keys
                "backup"       => "unknown",
                "security"     => "unknown",
                "staging"      => "unknown",
                "activity_log" => "unknown",
                "performance"  => "unknown",
            ];

           
             return new WP_REST_Response([
                'success' => true,
                'message' => 'User authenticated successfully',
                'data'   => $payload,
            ], 200);
        } catch (\Throwable $e) {
            error_log('handle_status fatal: ' . $e->getMessage());
            return new \WP_REST_Response([
                'error'   => 'status_failed',
                'message' => $e->getMessage(),
            ], 500);
        }
    }
    public function update_item(\WP_REST_Request $request)
    {

        // Verify credentials for this API call
        $cred_check = $this->verify_creds($request);
        if ($cred_check !== true) {
            return $cred_check;
        }

        $type   = $request->get_param('type');   // plugin, theme, core
        $slug   = $request->get_param('slug');   // e.g. "akismet/akismet.php" or "twentytwentyfive"
        $action = $request->get_param('action'); // update, activate, deactivate

        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/theme.php';
        require_once ABSPATH . 'wp-admin/includes/update.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/misc.php';

        wp_cache_flush();

        $result = null;

        // ✅ PLUGIN actions
        if ($type === 'plugin' && $slug) {
            if ($action === 'update') {
                wp_update_plugins();
                $upgrader = new \Plugin_Upgrader(new \Automatic_Upgrader_Skin());
                $result   = $upgrader->upgrade($slug);
            } elseif ($action === 'activate') {
                $result = activate_plugin($slug);
                if (is_wp_error($result)) {
                    return new \WP_REST_Response(['error' => $result->get_error_message()], 500);
                }
            } elseif ($action === 'deactivate') {
                deactivate_plugins($slug);
                $result = true;
            } elseif ($action === 'delete') {
                // Slug must be plugin file path like "akismet/akismet.php"
                $result = delete_plugins([$slug]);
                if (is_wp_error($result)) {
                    return new \WP_REST_Response(['error' => $result->get_error_message()], 500);
                }
            }
        }

        // ✅ THEME actions
        elseif ($type === 'theme' && $slug) {
            if ($action === 'update' && $slug) {
                wp_update_themes();
                $upgrader = new \Theme_Upgrader(new \Automatic_Upgrader_Skin());
                $result   = $upgrader->upgrade($slug);
            } elseif ($action === 'activate' && $slug) {
                switch_theme($slug);
                $result = true;
            } elseif ($action === 'deactivate' && $slug) {
                // WordPress doesn’t allow "deactivate theme" directly, 
                // you can only switch to another one.
                $result = 'Theme cannot be deactivated without switching to another theme';
            } elseif ($action === 'delete' && $slug) {
                // Slug must be theme folder name like "twentytwentyfive"
                if (wp_get_theme()->get_stylesheet() === $slug) {
                    return new \WP_REST_Response(['error' => 'Cannot delete the currently active theme'], 400);
                }
                $result = delete_theme($slug);
                if (is_wp_error($result)) {
                    return new \WP_REST_Response(['error' => $result->get_error_message()], 500);
                }
            }
        }

        // ✅ CORE update only
        elseif ($type === 'core' && $action === 'update') {
            $updates = get_site_transient('update_core');
            if (!empty($updates->updates) && is_array($updates->updates)) {
                $update = $updates->updates[0]; // first available update

                if (!empty($update->response) && $update->response === 'upgrade') {
                    $upgrader = new \Core_Upgrader(new \Automatic_Upgrader_Skin());
                    $result   = $upgrader->upgrade($update);

                    if (is_wp_error($result)) {
                        $response = [
                            'status'  => 'error',
                            'message' => $result->get_error_message(),
                        ];
                    } else {
                        $response = [
                            'status'  => 'success',
                            'message' => 'WordPress core updated successfully',
                            'result'  => $result,
                        ];
                    }
                } else {
                    $response = [
                        'status'  => 'ok',
                        'message' => 'No core update required',
                    ];
                }
            } else {
                wp_version_check();
                $update = find_core_update(false, false);

                if ($update) {
                    $upgrader = new \Core_Upgrader(new \Automatic_Upgrader_Skin());
                    $result   = $upgrader->upgrade($update);
                } else {
                    $result = 'No core update available';
                }
            }
        } else {
            return new \WP_REST_Response([
                'error' => 'Invalid request. Provide type=plugin|theme|core, slug if needed, and action=update|activate|deactivate'
            ], 400);
        }

        if ($result === false) {
            return new \WP_REST_Response(['message' => ucfirst($type) . ' action failed'], 500);
        }

        
        return new \WP_REST_Response([
            'success' => true,
            'status'  => 'success',
            'message' => ucfirst($type) . ' ' . $action . ' process completed',
            'result'  => $result,
        ], 200);
    }



    public function manage_users(\WP_REST_Request $request)
    {
        // Verify credentials for this API call
        $cred_check = $this->verify_creds($request);
        if ($cred_check !== true) {
            return $cred_check;
        }
        try {
            $action = $request->get_param('action'); // create, update, delete, get, list
            $user_id = $request->get_param('id');

            // CREATE user
            if ($action === 'create') {
                $userdata = [
                    'user_login' => sanitize_user($request->get_param('username')),
                    'user_email' => sanitize_email($request->get_param('email')),
                    'user_pass'  => $request->get_param('password'),
                    'display_name' => sanitize_text_field($request->get_param('name')),
                    'role' => $request->get_param('role') ?? 'subscriber',
                ];
                $result = wp_insert_user($userdata);
                if (is_wp_error($result)) {
                    return new \WP_REST_Response(['error' => $result->get_error_message()], 500);
                }
            }

            // UPDATE user
            elseif ($action === 'update' && $user_id) {
                $userdata = ['ID' => (int)$user_id];
                if ($request->get_param('email')) $userdata['user_email'] = sanitize_email($request->get_param('email'));
                if ($request->get_param('name')) $userdata['display_name'] = sanitize_text_field($request->get_param('name'));
                if ($request->get_param('password')) $userdata['user_pass'] = $request->get_param('password');
                if ($request->get_param('role')) $userdata['role'] = $request->get_param('role');

                $result = wp_update_user($userdata);
                if (is_wp_error($result)) {
                    return new \WP_REST_Response(['error' => $result->get_error_message()], 500);
                }
            }

            // DELETE user
            elseif ($action === 'delete' && $user_id) {
                require_once ABSPATH . 'wp-admin/includes/user.php';
                $reassign = $request->get_param('reassign') ?? null; // reassign posts to another user ID
                $result = wp_delete_user((int)$user_id, $reassign);
                if (!$result) {
                    return new \WP_REST_Response(['error' => 'User deletion failed'], 500);
                }
            }

            // GET single user
            elseif ($action === 'get' && $user_id) {
                $user = get_userdata((int)$user_id);
                if (!$user) {
                    return new \WP_REST_Response(['error' => 'User not found'], 404);
                }
                $result = [
                    'id' => $user->ID,
                    'username' => $user->user_login,
                    'email' => $user->user_email,
                    'name' => $user->display_name,
                    'roles' => $user->roles,
                ];
            }

            // LIST all users
            elseif ($action === 'list') {
                $args = [
                    'role__in' => $request->get_param('roles') ? explode(',', $request->get_param('roles')) : [],
                    'number'   => $request->get_param('per_page') ?? 20,
                    'paged'    => $request->get_param('page') ?? 1,
                ];
                $users = get_users($args);
                $result = array_map(function ($user) {
                    return [
                        'id' => $user->ID,
                        'username' => $user->user_login,
                        'email' => $user->user_email,
                        'name' => $user->display_name,
                        'roles' => $user->roles,
                    ];
                }, $users);
            } else {
                return new \WP_REST_Response(['error' => 'Invalid action'], 400);
            }

            return new \WP_REST_Response([
                'message' => 'User action completed',
                'result' => $result,
            ], 200);
        } catch (\Throwable $e) {
            return new \WP_REST_Response([
                'error' => 'user_action_failed',
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function handle_backup(\WP_REST_Request $req)
    {
        // Verify credentials for this API call
        $cred_check = $this->verify_creds($req);
        if ($cred_check !== true) {
            return $cred_check;
        }
        try {
            $type       = $req->get_param('type') ?? 'files'; // db | files | both
            $website_id = $req->get_param('website_id') ?? '';
            $laravel_url = $req->get_param('laravel_url') ?? '';

            // 🔹 Use wp-content/uploads/backups instead of sys temp dir
            $upload_dir = wp_upload_dir();
            $backup_dir = $upload_dir['basedir'] . '/laravel_backups';
            if (!file_exists($backup_dir)) {
                wp_mkdir_p($backup_dir);
            }

            $state_file = $backup_dir . '/backup_state.json';
            $zip_file   = $backup_dir . '/backup_' . $type . '.zip';
            $root       = ABSPATH;
            $batch_size = 500;

            $completed = false;
            $files = [];

            // ---- FILES BACKUP ----
            if ($type === 'files') {
                if (file_exists($state_file)) {
                    $state = json_decode(file_get_contents($state_file), true);
                } else {
                    $all_files = [];
                    $iterator = new RecursiveIteratorIterator(
                        new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS),
                        RecursiveIteratorIterator::LEAVES_ONLY
                    );
                    foreach ($iterator as $file) {
                        $relative = substr($file->getRealPath(), strlen($root));
                        if (strpos($relative, 'wp-content/cache') !== false) continue;
                        $all_files[] = [$file->getRealPath(), $relative];
                    }

                    $state = [
                        'files'      => $all_files,
                        'position'   => 0,
                        'zip_opened' => false,
                    ];
                }

                $zip = new ZipArchive();
                if (!$state['zip_opened']) {
                    $zip->open($zip_file, ZipArchive::CREATE);
                    $state['zip_opened'] = true;
                } else {
                    $zip->open($zip_file);
                }

                $end = min($state['position'] + $batch_size, count($state['files']));
                for ($i = $state['position']; $i < $end; $i++) {
                    $zip->addFile($state['files'][$i][0], $state['files'][$i][1]);
                }
                $zip->close();

                $state['position'] = $end;

                if ($state['position'] >= count($state['files'])) {
                    $completed = true;
                    unlink($state_file);
                } else {
                    file_put_contents($state_file, json_encode($state));
                }

                // return URL instead of local path
                $files['files_zip'] = $upload_dir['baseurl'] . '/laravel_backups/backup_files.zip';
            }

            // ---- DATABASE BACKUP ----
            if ($type === 'db') {
                global $wpdb;
                $db_file = $backup_dir . '/db_backup.sql';

                $files['db_file'] = $upload_dir['baseurl'] . '/laravel_backups/db_backup.sql';

                $db_host = DB_HOST;
                $db_name = DB_NAME;
                $db_user = DB_USER;
                $db_pass = DB_PASSWORD;

                try {
                    // simple PHP export (to keep it portable)
                    $handle = fopen($db_file, 'w');
                    if (!$handle) {
                        throw new \Exception("Cannot open file for writing: $db_file");
                    }

                    $tables = $wpdb->get_col("SHOW TABLES");
                    foreach ($tables as $table) {
                        $create = $wpdb->get_row("SHOW CREATE TABLE `$table`", ARRAY_N);
                        fwrite($handle, $create[1] . ";\n\n");

                        $rows = $wpdb->get_results("SELECT * FROM `$table`", ARRAY_A);
                        foreach ($rows as $row) {
                            $vals = array_map(function ($v) {
                                return isset($v) ? "'" . addslashes($v) . "'" : 'NULL';
                            }, array_values($row));
                            fwrite($handle, "INSERT INTO `$table` VALUES(" . implode(',', $vals) . ");\n");
                        }
                        fwrite($handle, "\n\n");
                    }
                    fclose($handle);

                    $completed = true;
                } catch (\Exception $e) {
                    throw new \Exception("Database backup failed: " . $e->getMessage());
                }
            }

            return new \WP_REST_Response([
                'status'      => $completed ? 'completed' : 'in_progress',
                'backup_type' => $type,
                'files'       => $files,
                'next_batch'  => $completed ? null : ($state['position'] ?? null),
                'total_files' => isset($state['files']) ? count($state['files']) : null,
            ], 200);
        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'error'   => 'backup_failed',
                'message' => $e->getMessage(),
                'trace'   => $e->getTraceAsString(),
            ], 200);
        }
    }


    function send_backup_to_laravel(\WP_REST_Request $request)
    {
        // Verify credentials for this API call
        $cred_check = $this->verify_creds($request);
        if ($cred_check !== true) {
            return $cred_check;
        }
        try {
            $laravel_api = $request->get_param('laravel_api_url');
            $filePath    = $request->get_param('file_path'); // change path dynamically
            $website_id  = $request->get_param('website_id');
            $type        = $request->get_param('type');

            if (!file_exists($filePath)) {
                return ['success' => false, 'error' => 'Backup file not found: ' . $filePath];
            }

            // Use CURL directly because wp_remote_post does not support 'files'
            $curl = curl_init();
            $cfile = new CURLFile($filePath, mime_content_type($filePath), basename($filePath));

            $postData = [
                'website_id' => $website_id,
                'type'       => $type,
                'file'       => $cfile
            ];

            curl_setopt_array($curl, [
                CURLOPT_URL            => $laravel_api,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST           => false,
                CURLOPT_POSTFIELDS     => $postData,
            ]);

            $response = curl_exec($curl);

            if (curl_errno($curl)) {
                return new \WP_REST_Response([
                    'status'      => false,
                    'error' => curl_error($curl)
                ]);
            }
            curl_close($curl);
            return new \WP_REST_Response([
                'status'      => true,
                'responce' =>  json_decode($response, true)
            ]);
        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'status'      => false,
                'error' => $e->getMessage()
            ]);
        }
    }




    public function check_backup_status(\WP_REST_Request $req)
    {
        // Verify credentials for this API call
        $cred_check = $this->verify_creds($req);
        if ($cred_check !== true) {
            return $cred_check;
        }
        try {
            $backup_dir = sys_get_temp_dir() . '/wp_backups';

            if (!file_exists($backup_dir)) {
                return new \WP_REST_Response([
                    'success' => true,
                    'message' => 'No backup directory found, nothing to clean.',
                ], 200);
            }

            $deleted = [];
            $files = glob($backup_dir . '/*'); // all files in backup dir
            foreach ($files as $file) {
                if (is_file($file)) {
                    unlink($file);
                    $deleted[] = $file;
                }
            }

            return new \WP_REST_Response([
                'success' => true,
                'deleted' => $deleted,
            ], 200);
        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }


    public function handle_delete_backup(\WP_REST_Request $req)
    {
        // Verify credentials for this API call
        $cred_check = $this->verify_creds($req);
        if ($cred_check !== true) {
            return $cred_check;
        }
        try {
            $upload_dir = wp_upload_dir();
            $backup_dir = $upload_dir['basedir'] . '/laravel_backups';

            if (!file_exists($backup_dir)) {
                return [
                    'success' => true,
                    'message' => 'No backups found (backup folder does not exist).'
                ];
            }

            $deleted = 0;
            $failed  = 0;

            $files = glob($backup_dir . '/*'); // all files inside backups/
            if ($files) {
                foreach ($files as $file) {
                    if (is_file($file)) {
                        if (@unlink($file)) {
                            $deleted++;
                        } else {
                            $failed++;
                        }
                    }
                }
            }

            return [
                'success' => true,
                'message' => "Deleted {$deleted} backup(s). " . ($failed ? "$failed failed." : "All clear."),
            ];
        } catch (\Exception $e) {
            return new WP_Error('delete_failed', $e->getMessage());
        }
    }


    function wp_db_optimizer_status(WP_REST_Request $request)
    {
        // Verify credentials for this API call
        $cred_check = $this->verify_creds($request);
        if ($cred_check !== true) {
            return $cred_check;
        }
        global $wpdb;

        $report = [];

        // 1. Post revisions, drafts, trash
        $report['posts'] = [
            'revisions'   => (int) $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_type='revision'"),
            'auto_drafts' => (int) $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status='auto-draft'"),
            'trashed'     => (int) $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status='trash'")
        ];

        // 2. Spam & trashed comments
        $report['comments'] = [
            'spam'   => (int) $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments WHERE comment_approved='spam'"),
            'trash'  => (int) $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments WHERE comment_approved='trash'")
        ];

        // 3. Orphaned postmeta
        $report['orphans'] = [
            'postmeta' => (int) $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->postmeta pm LEFT JOIN $wpdb->posts wp ON wp.ID = pm.post_id WHERE wp.ID IS NULL"),
            'usermeta' => (int) $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->usermeta um LEFT JOIN $wpdb->users wu ON wu.ID = um.user_id WHERE wu.ID IS NULL"),
            'commentmeta' => (int) $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->commentmeta cm LEFT JOIN $wpdb->comments c ON c.comment_ID = cm.comment_id WHERE c.comment_ID IS NULL")
        ];

        // 4. Autoloaded options
        $autoload_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->options WHERE autoload='yes'");
        $autoload_size  = (int) $wpdb->get_var("SELECT SUM(LENGTH(option_value)) FROM $wpdb->options WHERE autoload='yes'");
        $big_options = $wpdb->get_results("SELECT option_name, LENGTH(option_value) AS size FROM $wpdb->options WHERE autoload='yes' ORDER BY size DESC LIMIT 10", ARRAY_A);

        $report['autoload_options'] = [
            'count' => $autoload_count,
            'total_size_kb' => round($autoload_size / 1024, 2),
            'largest' => $big_options
        ];

        // 5. Table fragmentation (tables needing OPTIMIZE)
        $tables = $wpdb->get_results("SHOW TABLE STATUS WHERE Data_free > 0", ARRAY_A);
        $report['fragmented_tables'] = $tables;

        return rest_ensure_response([
            'status' => 'ok',
            'optimization_report' => $report
        ]);
    }

    function wp_db_optimizer_action(WP_REST_Request $request)
    {
        // Verify credentials for this API call
        $cred_check = $this->verify_creds($request);
        if ($cred_check !== true) {
            return $cred_check;
        }
        global $wpdb;
        $action = sanitize_text_field($request->get_param('action')); // e.g., delete_revisions

        $results = [];

        switch ($action) {
            case 'delete_revisions':
                $deleted = $wpdb->query("DELETE FROM $wpdb->posts WHERE post_type='revision'");
                $results['deleted_revisions'] = $deleted;
                break;

            case 'delete_auto_drafts':
                $deleted = $wpdb->query("DELETE FROM $wpdb->posts WHERE post_status='auto-draft'");
                $results['deleted_auto_drafts'] = $deleted;
                break;

            case 'empty_trash_posts':
                $deleted = $wpdb->query("DELETE FROM $wpdb->posts WHERE post_status='trash'");
                $results['deleted_trashed_posts'] = $deleted;
                break;

            case 'delete_spam_comments':
                $deleted = $wpdb->query("DELETE FROM $wpdb->comments WHERE comment_approved='spam'");
                $results['deleted_spam_comments'] = $deleted;
                break;

            case 'delete_trash_comments':
                $deleted = $wpdb->query("DELETE FROM $wpdb->comments WHERE comment_approved='trash'");
                $results['deleted_trashed_comments'] = $deleted;
                break;

            case 'delete_orphan_postmeta':
                $deleted = $wpdb->query("DELETE pm FROM $wpdb->postmeta pm LEFT JOIN $wpdb->posts p ON p.ID = pm.post_id WHERE p.ID IS NULL");
                $results['deleted_orphan_postmeta'] = $deleted;
                break;

            case 'delete_orphan_usermeta':
                $deleted = $wpdb->query("DELETE um FROM $wpdb->usermeta um LEFT JOIN $wpdb->users u ON u.ID = um.user_id WHERE u.ID IS NULL");
                $results['deleted_orphan_usermeta'] = $deleted;
                break;

            case 'delete_orphan_commentmeta':
                $deleted = $wpdb->query("DELETE cm FROM $wpdb->commentmeta cm LEFT JOIN $wpdb->comments c ON c.comment_ID = cm.comment_id WHERE c.comment_ID IS NULL");
                $results['deleted_orphan_commentmeta'] = $deleted;
                break;

            case 'delete_expired_transients':
                $deleted = $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_timeout_%' AND option_value < UNIX_TIMESTAMP()");
                $results['deleted_expired_transients'] = $deleted;
                break;

            case 'optimize_tables':
                $tables = $wpdb->get_col("SHOW TABLES");
                $optimized = [];
                foreach ($tables as $table) {
                    $wpdb->query("OPTIMIZE TABLE $table");
                    $optimized[] = $table;
                }
                $results['optimized_tables'] = $optimized;
                break;

            default:
                return rest_ensure_response([
                    'status'  => 'error',
                    'message' => 'Invalid action. Allowed actions: delete_revisions, delete_auto_drafts, empty_trash_posts, delete_spam_comments, delete_trash_comments, delete_orphan_postmeta, delete_orphan_usermeta, delete_orphan_commentmeta, delete_expired_transients, optimize_tables'
                ]);
        }

        return rest_ensure_response([
            'status'  => 'success',
            'action'  => $action,
            'results' => $results
        ]);
    }

    function wp_security_report(WP_REST_Request $request)
    {
        // Verify credentials for this API call
        $cred_check = $this->verify_creds($request);
        if ($cred_check !== true) {
            return $cred_check;
        }
        global $wpdb;

        // helper
        $is_writable = fn($path) => @is_writable($path);

        // Basic environment
        $wp_version = get_bloginfo('version');
        $php_version = phpversion();
        $db_version = $wpdb->db_version();
        $is_ssl = is_ssl();

        // Core security-related constants / settings
        $constants = [
            'DISALLOW_FILE_MODS'         => defined('DISALLOW_FILE_MODS') ? DISALLOW_FILE_MODS : false,
            'DISALLOW_FILE_EDIT'         => defined('DISALLOW_FILE_EDIT') ? DISALLOW_FILE_EDIT : false,
            'AUTOMATIC_UPDATER_DISABLED' => defined('AUTOMATIC_UPDATER_DISABLED') ? AUTOMATIC_UPDATER_DISABLED : false,
            'WP_DEBUG'                   => defined('WP_DEBUG') ? WP_DEBUG : false,
            'WP_DEBUG_LOG'               => defined('WP_DEBUG_LOG') ? WP_DEBUG_LOG : false,
            'FORCE_SSL_ADMIN'            => defined('FORCE_SSL_ADMIN') ? FORCE_SSL_ADMIN : false,
        ];

        // Check salts
        $salt_keys = [
            'AUTH_KEY',
            'SECURE_AUTH_KEY',
            'LOGGED_IN_KEY',
            'NONCE_KEY',
            'AUTH_SALT',
            'SECURE_AUTH_SALT',
            'LOGGED_IN_SALT',
            'NONCE_SALT'
        ];
        $salts = [];
        foreach ($salt_keys as $k) {
            $present = defined($k);
            $value_ok = false;
            if ($present) {
                $val = constant($k);
                $value_ok = (is_string($val) && strlen($val) >= 40 && strpos($val, 'put your unique phrase here') === false);
            }
            $salts[$k] = ['defined' => $present, 'strong' => $value_ok];
        }

        // File system checks
        $wp_config_path = ABSPATH . 'wp-config.php';
        $htaccess_path = ABSPATH . '.htaccess';
        $upload_dir = wp_upload_dir();
        $uploads_path = $upload_dir['basedir'];

        $fs = [
            'wp_config_exists' => file_exists($wp_config_path),
            'wp_config_writable' => $is_writable($wp_config_path),
            'htaccess_exists' => file_exists($htaccess_path),
            'htaccess_writable' => file_exists($htaccess_path) ? $is_writable($htaccess_path) : null,
            'uploads_writable' => is_dir($uploads_path) ? $is_writable($uploads_path) : false,
        ];

        // XML-RPC (old attack surface)
        // xmlrpc.php exists by default — check if requests to it are blocked by option or plugin
        $xmlrpc_exists = file_exists(ABSPATH . 'xmlrpc.php');
        // Many sites disable xmlrpc by plugins or .htaccess; we can only report presence here
        $xmlrpc_enabled = $xmlrpc_exists && !apply_filters('xmlrpc_enabled', true) ? false : $xmlrpc_exists;

        // Admin user name check: existence of common usernames like 'admin'
        $common_usernames = ['admin', 'administrator', 'test', 'root'];
        $users_with_common = [];
        foreach ($common_usernames as $u) {
            $user = get_user_by('login', $u);
            if ($user) $users_with_common[] = $u;
        }
        // count admin users
        $admin_count = count(get_users(['role' => 'administrator', 'fields' => 'ID']));

        // Active plugins & themes
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/theme.php';

        $active_plugins = get_option('active_plugins', []);
        $plugins_info = [];
        foreach ($active_plugins as $plugin_file) {
            $data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin_file, false, false);
            $plugins_info[] = [
                'file' => $plugin_file,
                'name' => $data['Name'] ?? $plugin_file,
                'version' => $data['Version'] ?? null,
                'network_active' => is_plugin_active_for_network($plugin_file),
            ];
        }

        $current_theme = wp_get_theme();
        $theme_info = [
            'name' => $current_theme->get('Name'),
            'version' => $current_theme->get('Version'),
            'parent' => $current_theme->parent() ? $current_theme->parent()->get('Name') : null,
        ];

        // Update availability (core/plugins/themes)
        // Use admin includes to access update info
        require_once ABSPATH . 'wp-admin/includes/update.php';
        wp_update_themes();         // refresh theme update info
        wp_update_plugins();        // refresh plugin update info
        wp_version_check();         // refresh core update info

        $updates = [
            'core_update' => get_core_updates(),
            'plugin_updates' => get_plugin_updates(),
            'theme_updates' => get_theme_updates(),
        ];

        // DB access rights check (simple test)
        $can_create_table = false;
        try {
            $tmp_table = $wpdb->prefix . 'tmp_security_check';
            $wpdb->query("CREATE TABLE IF NOT EXISTS {$tmp_table} (id INT) ENGINE=InnoDB");
            $can_create_table = true;
            $wpdb->query("DROP TABLE IF EXISTS {$tmp_table}");
        } catch (Exception $e) {
            $can_create_table = false;
        }

        // Brute-force protection / login limits: check common plugins presence
        $login_protection_plugins = ['limit-login-attempts', 'wordfence', 'loginizer', 'jetpack'];
        $found_login_protection = [];
        foreach ($plugins_info as $p) {
            foreach ($login_protection_plugins as $needle) {
                if (stripos($p['file'], $needle) !== false || stripos($p['name'], $needle) !== false) {
                    $found_login_protection[] = $p['name'];
                }
            }
        }

        // Basic password policy check (none built-in) — report if any plugin appears that enforces passwords
        $password_policy_plugins = ['password-policy', 'force-strong-passwords', 'wp-password-policy-manager'];
        $found_password_policy = [];
        foreach ($plugins_info as $p) {
            foreach ($password_policy_plugins as $needle) {
                if (stripos($p['file'], $needle) !== false || stripos($p['name'], $needle) !== false) {
                    $found_password_policy[] = $p['name'];
                }
            }
        }

        // Compose report with recommendations
        $report = [
            'env' => [
                'wp_version' => $wp_version,
                'php_version' => $php_version,
                'mysql_version' => $db_version,
                'is_ssl' => $is_ssl,
            ],
            'constants' => $constants,
            'salts' => $salts,
            'filesystem' => $fs,
            'xmlrpc' => ['exists' => $xmlrpc_exists, 'enabled' => $xmlrpc_enabled],
            'users' => [
                'admin_count' => $admin_count,
                'weak_usernames_found' => $users_with_common,
            ],
            'plugins' => [
                'active' => $plugins_info,
                'plugin_updates_count' => count($updates['plugin_updates']),
                'plugin_updates' => array_values(array_map(function ($k, $v) {
                    return ['file' => $k, 'data' => $v];
                }, array_keys($updates['plugin_updates']), $updates['plugin_updates'])),
                'found_login_protection' => array_values(array_unique($found_login_protection)),
                'found_password_policy' => array_values(array_unique($found_password_policy)),
            ],
            'theme' => [
                'current' => $theme_info,
                'theme_updates_count' => count($updates['theme_updates']),
                'theme_updates' => array_values(array_map(function ($k, $v) {
                    return ['theme' => $k, 'data' => $v];
                }, array_keys($updates['theme_updates']), $updates['theme_updates'])),
            ],
            'updates' => [
                'core' => $updates['core_update'] ? $updates['core_update'] : [],
            ],
            'db_tests' => [
                'can_create_table' => $can_create_table,
            ],
            'recommendations' => []
        ];

        // Simple automated recommendations
        if (!$is_ssl) {
            $report['recommendations'][] = 'Enable HTTPS and FORCE_SSL_ADMIN to protect credentials and cookies.';
        }
        if ($constants['WP_DEBUG']) {
            $report['recommendations'][] = 'Disable WP_DEBUG on production (set WP_DEBUG false).';
        }
        if (!$constants['DISALLOW_FILE_EDIT']) {
            $report['recommendations'][] = 'Set DISALLOW_FILE_EDIT to true to prevent code edits from the admin UI.';
        }
        if (!$salts['AUTH_KEY']['strong'] || !$salts['SECURE_AUTH_KEY']['strong']) {
            $report['recommendations'][] = 'Ensure all authentication salts in wp-config.php are present and strong. Regenerate if needed.';
        }
        if ($fs['wp_config_writable']) {
            $report['recommendations'][] = 'Make wp-config.php read-only or reduce webserver write access.';
        }
        if ($admin_count > 2) {
            $report['recommendations'][] = 'Review administrator accounts and remove unnecessary admin users.';
        }
        if (!empty($users_with_common)) {
            $report['recommendations'][] = 'Remove common usernames like "admin"; rename or change if found.';
        }
        if (!empty($updates['plugin_updates'])) {
            $report['recommendations'][] = 'Update plugins: some plugins have available updates.';
        }
        if (!empty($updates['theme_updates'])) {
            $report['recommendations'][] = 'Update themes: some themes have available updates.';
        }
        if (!empty($updates['core_update'])) {
            $report['recommendations'][] = 'Update WordPress core when possible (backup first).';
        }
        if (empty($found_login_protection)) {
            $report['recommendations'][] = 'Install a login protection plugin (rate limit / lockouts) to reduce brute-force risk.';
        }

        return rest_ensure_response([
            'status' => 'ok',
            'security_report' => $report
        ]);
    }

    function get_ssl_certificate_details()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $port   = 443;

        $streamContext = stream_context_create([
            "ssl" => [
                "capture_peer_cert" => true,
                "verify_peer"       => false,
                "verify_peer_name"  => false,
            ]
        ]);

        $client = @stream_socket_client(
            "ssl://{$domain}:{$port}",
            $errno,
            $errstr,
            30,
            STREAM_CLIENT_CONNECT,
            $streamContext
        );

        if (!$client) {
            return [
                'status'  => 'error',
                'message' => "Could not connect to {$domain}:{$port}. Error: $errstr ($errno)"
            ];
        }

        $context     = stream_context_get_params($client);
        $certDetails = openssl_x509_parse($context["options"]["ssl"]["peer_certificate"]);

        if (!$certDetails) {
            return [
                'status'  => 'error',
                'message' => 'Could not parse SSL certificate.'
            ];
        }

        $validFrom = date(DATE_RFC2822, $certDetails['validFrom_time_t']);
        $validTo   = date(DATE_RFC2822, $certDetails['validTo_time_t']);
        $daysLeft  = floor(($certDetails['validTo_time_t'] - time()) / 86400);

        // ✅ Check if certificate is expired
        $isExpired = $daysLeft < 0;

        return [
            'status'     => $isExpired ? 'expired' : 'valid',
            'domain'     => $domain,
            'issuer'     => $certDetails['issuer']['CN'] ?? 'Unknown',
            'valid_from' => $validFrom,
            'valid_to'   => $validTo,
            'days_left'  => $daysLeft,
            'message'    => $isExpired
                ? "SSL certificate has expired on {$validTo}"
                : "SSL certificate is valid for {$daysLeft} more days"
        ];
    }


    /**
     * Helper to produce consistent error responses.
     */
    private function error($code, $status = 400)
    {
        return new \WP_REST_Response(['error' => $code], $status);
    }
}

new Laravel_SSO_Bridge();

add_action('sso_run_backup', 'sso_run_backup_function', 10, 2);

function sso_run_backup_function($type, $timestamp)
{
    $upload_dir = wp_upload_dir();
    $backup_dir = $upload_dir['basedir'] . '/laravel_backups';
    $status_file = $backup_dir . "/status.json";
    if (!file_exists($backup_dir)) {
        wp_mkdir_p($backup_dir);
    }

    $backup_file = $backup_dir . "/backup_{$type}_{$timestamp}.zip";

    try {
        $zip = new ZipArchive();
        if ($zip->open($backup_file, ZipArchive::CREATE) !== TRUE) {
            throw new Exception('Cannot create zip file');
        }

        // Backup database
        if ($type == 'db' || $type == 'both') {
            global $wpdb;
            $db_file = $backup_dir . "/db_{$timestamp}.sql";
            $cmd = sprintf(
                'mysqldump --user=%s --password=%s --host=%s %s > %s',
                DB_USER,
                DB_PASSWORD,
                DB_HOST,
                DB_NAME,
                $db_file
            );
            system($cmd);
            if (file_exists($db_file)) {
                $zip->addFile($db_file, basename($db_file));
            }
        }

        // Backup WordPress files
        if ($type == 'files' || $type == 'both') {
            $root_path = realpath(ABSPATH);
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($root_path),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            foreach ($iterator as $file) {
                if (!$file->isDir()) {
                    $filePath = $file->getRealPath();
                    $relativePath = substr($filePath, strlen($root_path) + 1);
                    $zip->addFile($filePath, $relativePath);
                }
            }
        }

        $zip->close();

        // Update status
        file_put_contents($status_file, json_encode([
            'status' => 'completed',
            'type' => $type,
            'started_at' => $timestamp,
            'completed_at' => date('Y-m-d H:i:s'),
            'file' => basename($backup_file)
        ]));
    } catch (Exception $e) {
        file_put_contents($status_file, json_encode([
            'status' => 'failed',
            'type' => $type,
            'started_at' => $timestamp,
            'completed_at' => date('Y-m-d H:i:s'),
            'file' => null,
            'error' => $e->getMessage()
        ]));
    }
}
